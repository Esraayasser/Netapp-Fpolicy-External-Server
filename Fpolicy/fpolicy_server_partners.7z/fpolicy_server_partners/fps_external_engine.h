/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_external_engine.h
 *
 * @author Sudip Kumar Panda
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 * @brief This file contains declaration of FSMConnection class.
 */

#ifndef _FSM_EXTERNAL_ENGINE_H_
#define _FSM_EXTERNAL_ENGINE_H_

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <openssl/crypto.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/uio.h>
#include <netinet/tcp.h> ///< Need this for linux version.

#include "fps_notification.h"

//#include <syslog.h>


///Should we add a check on maximum number of servers that I/O thread will
///try when Fpolicy servers are not available. This is required because
///Fpolicy server can be added and removed and this might take when Fpolicy
///server is added and removed in a loop by a script, I/O thread will spin
///starving other requests.

///When a LIF moves to a node in that case we need to connect to FPolicy
///server even if maximum connect has been done. In such case we should call
///force connect.

///Things to look at in SSL.
///ssl_locks
///

#define MAX_ENG_NAME_LEN 256 ///TBD: Need to revisit.
#define MAX_SSL_COMMON_NAME_LEN 256 ///TBD: Need to revisit.
#define MAX_IP_ADDRESS_LEN 256 ///TBD: Need to revisit.
#define MAX_FQDN_LEN 1024 //TBD: Need to revisit.
#define RANDOM_BUF_LEN 1024 //< Random Buffer length
//#define IPV4_DEFINE 1
#define V4MAPPED_V6ADDR_PREFIX "::FFFF:"
#define EP_HEADER_LEN 6 ///< External protocol header length
#define MAX_EP_NOTIFICATION_LEN 8192
#define READ_TIMEOUT 1 ///<Read Timeout is set to 1sec.
#define WRITE_TIMEOUT 1 ///<Write timeout is set to 1sec.
#define MAX_SUPPORTED_CIPHERS 6 ///< Max Supported Cipher
#define MAX_SUPPORTED_CIPHER_LEN 256 ///< Max Supported Cipher Length
#define SSL_SHUTDOWN_TIME  1 ///< SSL shutdown. Set to 1sec.
#define MAX_CERT_PATH_LEN  1024
#define INVALID_FD -1 ///< Invalid FD
#define MAX_POLICY_LEN 256
#define FPS_MAX_UUID_LEN 36

#ifdef LINUX
#define SOCKET_RECV_BUF_SIZ (256*1024) ///< Make sure you don't overflow integer
#define SOCKET_SEND_BUF_SIZ (256*1024) ///< Make sure you don't overflow integer
#else
#define SOCKET_RECV_BUF_SIZ (128*1024) ///< Make sure you don't overflow integer
#define SOCKET_SEND_BUF_SIZ (128*1024) ///< Make sure you don't overflow integer
#endif


class FSMConnection;
typedef enum {
    INVALID_STATE = 0, ///< Invalid.
    SSLREQ        = 1,
    SSLDONE       = 2,
    HANDSHAKEREQ  = 3, ///< Handshake Req.
    HANDSHAKEDONE = 4, ///< Handshake Done.
    CLOSUREIINT   = 5, ///< Clousre initiated.
    FSMCLOSED     = 6, ///< FSM initiated close.
    FPSCLOSED     = 7  ///< Fpolicy server initiated close.
} protocolState_e;

typedef enum {
    INVALID_ADDRTYPE = 0, ///< Invalid ADDRESS.
    IPV4TYPE         = 1, ///< IPV4 ADDRESS.
    IPV6TYPE         = 2, ///< IPV6 ADDRESS.
    HOSTNAME_TYPE    = 3, ///< HOSTNAME
} addressType_e;

typedef enum {
    INVALID_IP_TYPE  = 0,
    IPV4_ADDR        = 1,
    IPV6_ADDR        = 2
} ipAddressType_e;

class FSMConnection
{
    private :
        char              _FSMIpAddress[MAX_IP_ADDRESS_LEN + 1];
        char              _policyName[MAX_POLICY_LEN + 1];
        int               _connectedFd;
        pthread_t         _threadId;
        int               _vserverId;
        bool              _sslAuthEnabled;
        char              _sessionId[FPS_MAX_UUID_LEN + 1];
        pthread_mutex_t   _connSslMutex;
        char              _certPath[MAX_CERT_PATH_LEN + 1];
        SSL_CTX           *_sslContext;
        SSL               *_connSsl;
        BIO               *_connBIO;
        X509              *_certBuffer;
    public :
        FSMConnection(uint32_t   vsId,
                      char       *polName,
                      int        connectedFd,
                      bool       sslAuthEnabled,
                      char       *FSMIpAddr,
                      const char *sessionId,
                      pthread_t  threadId);

        ~FSMConnection();

        void    setDisconnectParams(void);
        int     recvNotification(void);
        int     fpServerSslInit(const char *CACertificate,
                             const char *PublicCertificate,
                             const char *PvtKey,
                             const char *PvtPasswd);
       int32_t  doSecNegotiationOverSsl(void);
       int32_t  doFpolicyHandshake(void);
       int      sendResponse(void);
       int32_t  sslHandshakeRecvMsg(unsigned char **respBuf,
                                    int *respLength);
       int32_t  disconnectFSM(void);
       int32_t  disconnectFSMOverSsl(void);
       int32_t  disconnectFSMOverTcp(void);
       int32_t  tcpHandshakeRecvMsg(unsigned char **respBuf,
                                    int *respLength);
       int32_t  sslRecvFSMXmlResp(unsigned char **respBuf,
                                  int *respLength);
       int32_t  sslSendFSMXmlReq(FSMXmlReq& reqToSend);
       int32_t  tcpRecvFSMXmlResp(unsigned char **respBuf,
                                  int32_t *respLength);
       int32_t  tcpSendFSMXmlReq(FSMXmlReq& reqToSend);
       int32_t  readAndEnqueue(void);
       int32_t  recvMsg(unsigned char **respBuf,
                        int32_t *respLength);
       int32_t  sendMsg(FSMXmlReq &xmlReqToSend);
       int32_t  processFSMRequest(unsigned char *respData,
                                  int32_t len);



};

int32_t isIPAddress(char *host, addressType_e& type);


#endif ///< ifndef _FSM_EXTERNAL_ENGINE_H_
