/**
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fsp_notification.h
 *
 * @author Sudip Kumar Panda
 *
 * @date 12-31-2011
 *
 * Languages Used : C & C++
 *
 * @brief This file contains classes and structures for
 *        formation of file screen notification and status
 *        notfication in XML format.
 *
 */

#ifndef _FSM_NOTIFICATION_H
#define _FSM_NOTIFICATION_H

#include <iostream>
#include <string>
#include <list>
#include <map>
#include <uuid.h>
#include <syslog.h>
#include <stdlib.h>
#include "fps_types.h"

using namespace std;
#define UNLIKELY(res) (__builtin_expect((res), 0))
#define ChkMemFatal(ptr) { if(UNLIKELY(!(ptr))) {abort(); } }

#define MAX_SESSION_ID_LEN    36
#define MAX_ALERT_MSG_LEN      256
#define MAX_POLICY_NAME_LEN   256
#define MAX_CANCEL_REASON_LEN 256
#define MAX_REQ_TYPE_LEN 40
#define FPS_NOTIFICATION_NUM_THREADS 40
///Maximum volume length is taken from
///USER_SELECTABLE_VOLUME_NAME_LENGTH which is
///present in .../smf/src/types/volume_name.h file.
///The maximum lenght supported is 203 characters.
///No harm in rounding it off to 256 bytes.
#define MAX_VOLUME_NAME_LEN   256
#define MAX_VERSION_LEN 20

class FSMXmlReq;
class AlertNotification;
class MessageHeader;
class HandshakeResp;
class NotificationResp;
class StatusResp;
class BackPressure;
class FPS_Notification;
class FPS_NotificationList;
class FPS_NotificationTask;
class FSMConnection;
#include "fps_external_engine.h"

extern FPS_NotificationTask gFpsNotfObj;

/**
 * @class FSMXmlReq
 *
 * @brief This class is used to store the XML formatted request
 *        which will be sent to FPolicy server. This class is
 *        also used as base class for status notification message.
 *        This is a concrete class.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

class FSMXmlReq
{
    private :
        ///XML message buffer pointer pointing to XML formatted message.
        uint8_t         *_xmlMsgBuf;
        ///Length of the message buffer.
        uint32_t         _xmlMsgLength;
        ///Buffer used. This is used while constructing the XML message.
        uint32_t         _bufUsed;

    public :
        // @{
        /** @name FSMXmlreq member functions for accessing private members.
         */
        const uint8_t*      getXmlMsgBuf(void) const { return _xmlMsgBuf; }
        uint32_t            getXmlMsgLength(void) const { return _xmlMsgLength; }
        void                printAsciiXmlMsg(void) const;
        // @}

        // @{
        /** @name FSMXmlreq member functions used for manipulating private
         *        members while constructing an XML message for a notification.
         */
        Result_t            startXml(const char *header);
        Result_t            wrapXml(void);
        Result_t            checkAndRealloc(uint32_t reqSize);

        void                convStringToByte(const char *msgString);

        void                addUtf8ToByte(uint8_t  *utf8MsgPtr,
                                          uint32_t utf8MsgLength);
        // @}

        virtual void        populateXmlReq(void) {}

        FSMXmlReq() {
            _xmlMsgBuf    = NULL;
            _xmlMsgLength = 0;
            _bufUsed      = 0;
        }

        FSMXmlReq(const FSMXmlReq &src);

        virtual ~FSMXmlReq() {
            if(_xmlMsgBuf)
            {
                free(_xmlMsgBuf);
                _xmlMsgBuf = NULL;
            }
        }

        // @{
        /** @name FSMXmlreq overloaded operators for concatnating two FSMXmlReq
         *        and concatenating FSMXmlReqs with string object. References
         *        are returned chaining.
         */
        FSMXmlReq& operator=(const FSMXmlReq &src);
        FSMXmlReq& operator+=(const FSMXmlReq &src);
        FSMXmlReq& operator+=(const std::string &src);
        // @}
};

///Overload the + operator for merging FSMXmlReq(s).
FSMXmlReq operator+ (const FSMXmlReq &first,const FSMXmlReq &second);
FSMXmlReq operator+(const std::string &first,const FSMXmlReq &second);
FSMXmlReq operator+(const FSMXmlReq &first, const std::string &second);


/**
 * @class AlertNotification
 *
 * @brief This class is used for creation of a Alert notification
 *        request which will be sent to external FPolicy server.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

class AlertNotification : public FSMXmlReq {

    private :
        char      _sessionId[MAX_SESSION_ID_LEN + 1];
        char      _alertMsg[MAX_ALERT_MSG_LEN + 1];
        uint32_t  _severity;

    public :
        AlertNotification(const char      *sessionId,
                          const char      *alertMsg,
                          const uint32_t   serverity);

       ~AlertNotification() {}
        void      populateXmlReq(void);
};

/**
 * @class MessageHeader
 *
 * @brief This class is used for creation of a Message Header.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/21/2011
 *
 */

class MessageHeader : public FSMXmlReq
{
    private :
        fsm_request_type_e  _msgType;
        uint64_t            _contentLength;
        data_format_e       _dataFormat;
    public :
        MessageHeader(const fsm_request_type_e msgType,
                      const uint64_t           length,
                      const data_format_e      dataFormat) :
                      _msgType(msgType), _contentLength(length),
                      _dataFormat(dataFormat){}
       ~MessageHeader() {}
        void populateXmlReq(void);
};

/**
 * @class HandshakeResponse
 *
 * @brief This class is used to send FSM the handshake response.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

class HandshakeResp : public FSMXmlReq
{
    private :
        uint32_t                      _vserverId;
        char                          _VsUUID[MAX_SESSION_ID_LEN + 1];
        char                          _sessionId[MAX_SESSION_ID_LEN + 1];
        char                          _policyName[MAX_POLICY_NAME_LEN + 1];
        char                          _supportedVersions[MAX_VERSION_LEN + 1];

    public :
        //HandshakeResp (const uint32_t vserver, const char* session,
        //               const char    *policy, const char *supportedVers);

        HandshakeResp (const char    *vserverUUID, const char* session,
                       const char    *policy, const char *supportedVers);

        ~HandshakeResp() {}
        void populateXmlReq(void);
};

/**
 * @class Notifcation Response.
 *
 * @brief This class is used for creation Notification Response.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/21/2011
 *
 */

class NotificationResp : public FSMXmlReq
{
    private :
        uint64_t            _reqId;
        unsigned char       _reqType[MAX_REQ_TYPE_LEN + 1];
        uint32_t            _resp;
    public :
        NotificationResp(const uint64_t            reqId,
                         const unsigned char       *reqType,
                         const uint32_t            resp);
       ~NotificationResp() {}
        void populateXmlReq(void);
};

/**
 * @class Status Response.
 *
 * @brief This class is used for creation Status Response.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/21/2011
 *
 */

class StatusResp : public FSMXmlReq
{
    private :
        uint64_t            _reqId;
        unsigned char       _reqType[MAX_REQ_TYPE_LEN + 1];
        uint32_t            _statusResp;
    public :
        StatusResp(const uint64_t            reqId,
                   const unsigned char       *reqType,
                   const uint32_t            statusResp);

       ~StatusResp() {}
        void populateXmlReq(void);
};

/**
 * @class Back Pressure.
 *
 * @brief This class is used for creation Status Response.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/21/2011
 *
 */

class BackPressure : public FSMXmlReq
{
    private :
        unsigned char       _sessionId[MAX_SESSION_ID_LEN + 1];
        bool                _apply;
    public :
        BackPressure (const unsigned char  *sessionId,
                      bool          apply);
        ~BackPressure() {}
        void populateXmlReq(void);
};

/*FSMXmlReq*   populateXmlHandshakeResp(const uint32_t    vserverId,
                                      const char       *session,
                                      const char       *policy,
                                      const char       *supportedVersion);*/

FSMXmlReq*   populateXmlHandshakeResp(const char       *vserverUUID,
                                      const char       *session,
                                      const char       *policy,
                                      const char       *supportedVersion);

FSMXmlReq*   populateXmlNotificationResp(const uint64_t reqId,
                                         const unsigned char *reqType,
                                         const uint32_t resp);

FSMXmlReq*   populateXmlBackPressure(const unsigned char *sessionId,
                                     const bool   apply);

FSMXmlReq*   populateStatusResponse(const uint64_t reqId,
                                    const unsigned char *reqType,
                                    const uint32_t resp);


FSMXmlReq*   populateXmlAlertMsg(const char       *sessionId,
                                 const char       *alertMsg,
                                 const uint32_t    severity);

FSMXmlReq*   populateXmlHeaderMsg(const fsm_request_type_e megType,
                                  const uint64_t           length,
                                  const data_format_e      dataFormat);

class FPS_Notification
{
    private :
        unsigned char          *_msgBuf;
        int                     _msgLen;
        FSMConnection          *_connPtr;

    public :
        FPS_Notification(unsigned char *msgBuf, int msgLen,
                         FSMConnection *connPtr):
                         _msgBuf(msgBuf), _msgLen(msgLen),
                         _connPtr(connPtr) {};

        ~FPS_Notification() {
            if(_msgBuf)
            {
                free(_msgBuf);
                _msgBuf = NULL;
            }
        }

        /// We can argue why enqueueNotficationObj part of this class
        /// despite it not providing any sort of data-hiding but I kept
        /// it in this class because from the end user point of view
        /// he will have very little interface/object to interact with.
        void    enqueueNotficationObj(void);
        int     makeFpsCall(void);
};

class FPS_NotificationList
{
    private:
        std::list<FPS_Notification*>      _notificationQueue;
        pthread_mutex_t                   _notificationQueueMutex;
        pthread_cond_t                    _workerCv;
        uint32_t                          _workersWaiting;
        bool                              _shutdown;

    public:
        FPS_NotificationList();
        ~FPS_NotificationList();
        int32_t  dequeueNotfObj(FPS_Notification **element);
        int32_t  enqueueNotfObj(FPS_Notification *newElement);
        uint64_t getSize(void);
        void     setShutdown(void);
};

class FPS_NotificationTask
{
    private:
        FPS_NotificationList     _fpsNotificationObj;
        pthread_t                _workerThreadsId[FPS_NOTIFICATION_NUM_THREADS];
        bool                     _shutdown;

        void run(void);

        static void* workEntryFunc (void * obj)
        {
            ((FPS_NotificationTask *)obj)->run();
            return NULL;
        }

    public:
        void    startNotfWorkerThreads(void);
        void    waitForNotfWorkerThreads(void);
        void    stopNotfWorkerThreads(void);
        int32_t enqueueNotification(FPS_Notification *newel);
        int32_t dequeueNotification(FPS_Notification **newel);
        FPS_NotificationTask(void);
        ~FPS_NotificationTask(void) {}
};

#endif
