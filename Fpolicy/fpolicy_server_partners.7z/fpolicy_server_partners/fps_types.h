/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fsm_types.h
 *
 * @author Sandeep Joshi
 *
 * @date 12-15-2011
 *
 * Languages Used : C & C++
 *
 * @brief This file contains enums and macro definitions used in FSM.
 *
 */

#ifndef _FP_TYPES_H
#define _FP_TYPES_H

#include <iostream>
#include <time.h>

/******* Macros ***************/
#define RECV_BUF_SIZE           4096    //Receive buffer size
#define MAX_RESP_SIZE           1024    //Resp packet size

#define MAX_POL_PER_REQ         10      //Max policies
#define MAX_SERVER_PER_POLICY   20      //Max servers in a policy
#define MAX_NAME_LEN            256     //Max name length
#define MAX_IPADDR_LEN          40      //Max ipaddr length (IPv4 or IPv6)
#define MAX_ALERT_STR_LEN       512     //Max length of alert string
#define FP_MAX_UUID_LEN         36      ///< Maximum UUID length, Linux manpage says
                                        ///  it can be 36 chars. Didn't find any mention
                                        ///  in freebsd manpage. Linux manpage says it
                                        ///  is of 36-bytes and it is a DCE standard
                                        ///  safely assuming it will be of this length.

/* Configuration Defaults */
#define INVALID_ID                      0xffffffff
#define DEFAULT_PORT                    0xffffffff
#define DEFAULT_ENG_TYPE                ENG_TYPE_ASYNC
#define DEFAULT_POL_PRIORITY            1
#define DEFAULT_CANCEL_TIMEOUT          20
#define DEFAULT_ABORT_TIMEOUT           40
#define DEFAULT_STATUS_REQ_INTERVAL     10
#define DEFAULT_MAX_POL_REQ             1024
#define DEFAULT_MAX_CONN_RETRY          5
#define DEFAULT_MAX_SERVER_REQ          50
#define DEFAULT_SERVER_PROGRESS_TIMEOUT 60
#define DEFAULT_CRED_LIFETIME           (60*60*24)


/* This enum defines the screen request states */

enum request_type
{
    FPOLICY_REQUEST_NULL = 0,
    SMB_OPEN,
    SMB_CLOSE,
    SMB_CREAT,
    SMB_CREAT_DIR,
    SMB_DEL,
    SMB_DEL_DIR,
    SMB_REN,
    SMB_REN_DIR,
    SMB_GET_ATTR,
    SMB_SET_ATTR,
    SMB_LNK,
    SMB_SYM_LNK,
    SMB_RD,
    SMB_WR,
    NFS_LOOKUP,
    NFS_CREAT,
    NFS_CREAT_DIR,
    NFS_DEL,
    NFS_DEL_DIR,
    NFS_REN,
    NFS_REN_DIR,
    NFS_OPEN,
    NFS_CLOSE,
    NFS_RD,
    NFS_WR,
    NFS_GET_ATTR,
    NFS_SET_ATTR,
    NFS_LNK,
    NFS_SYM_LNK
};


typedef enum _fsm_request_type
{
	FSM_REQ_TYPE_INVALID = 0,
    NEGO_MSG_REQ ,
    NEGO_MSG_RESP,
    FILE_NOTIFY_REQ,
    FILE_NOTIFY_RESP,
    VOL_NOTIFY,
    FILE_NOTIFY_CANCEL_REQ,
    STATUS_QUERY_REQ,
    STATUS_QUERY_RESP,
    BACKBACK_RESSURE_APPLY_REQ,
    BACK_PRESSURE_REMOVE_REQ,
    KEEP_ALIVE_REQ,
    ALERTS
}fsm_request_type_e;


typedef enum data_format
{
    FORMAT_UNKNOWN = 0,
    FORMAT_XML
}data_format_e;

typedef enum
{
    REQ_STATUS_INVALID,
    REQ_STATUS_WORKING,
    REQ_STATUS_REJECT
}reqStatusCode_e;

typedef enum
{
    ALERT_SEVERITY_NONE,
    ALERT_SEVERITY_FATAL,
    ALERT_SEVERITY_WARNING
}alertSeverity_e;

typedef enum
{
        /* Only success code */
        /* NOTE: DO NOT ADD ANY OTHER SUCCESS RELATED CODES */
        RESULT_SUCCESS                                                  = 0,

        /* General: range (1-100) */
        RESULT_ERROR_GENERAL_MIN_VALUE                                  = 1,
        /* RESULT_ERROR_UNWIND_STACK has special control properties, see CHECK_FAIL_TAKE_ACTION */
        RESULT_ERROR_UNWIND_STACK                                       = 2,
        RESULT_ERROR_GENERAL_FAILURE                                    = 3,

        /* FPOLICY: range (8201-8300) */
        RESULT_ERROR_FPOLICY_MIN_VALUE                           = 4,
        RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION             = 5,
        RESULT_ERROR_FPOLICY_MAX_VALUE                          = 6,

    /* The max value of any current Result_t */
    RESULT_MAX_VALUE
} Result_t;


#endif
