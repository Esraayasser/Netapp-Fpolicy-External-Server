/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_server.h
 *
 * @author Sudip Kumar Panda
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 */

#ifndef _FPS_SERVER_H
#define _FPS_SERVER_H

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <openssl/crypto.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/select.h>
#include <syslog.h>
#include "fps_notification.h"


#define SERVER_CERT     "FPolicy-Server.cert"
#define SERVER_KEY      "FPolicy-Server.key"
#define CLIENT_CA_CERT  "ca.cert"
#define PASSWORD        "password"

int32_t acceptFSMConnection(void);

#if 0
#define syslog fprintf
#define LOG_ERR stderr
#endif
#define MAX_POLICY_LEN 256
#endif
