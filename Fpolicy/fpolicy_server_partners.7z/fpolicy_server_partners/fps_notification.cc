/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_notification.cc
 *
 * @author Sudip Kumar Panda
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 * @brief This file contains functions used for formation of
 *        notification request in XML format. This file contains
 *        definition of the member functions in FSMXmlReq class
 *        as well as helper routines for constructing a XML screen
 *        request. This file also contains definition of member
 *        functions in status class (e.g. AlertNotification,
 *        VolumeNotification etc.).
 *
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include "fps_notification.h"



///Static Function Declarations.
static void         addStartTag(FSMXmlReq                     &xmlReq,
                                const char                    *xmlTag);
static void         addEndTag(FSMXmlReq                       &xmlReq,
                              const char                      *xmlTag);

static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const uint32_t             value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const int32_t              value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const uint64_t             value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const int64_t              value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const bool                 value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const char                *value);
static void         addTagWithValue(FSMXmlReq                 &xmlReq,
                                    const char                *xmlTag,
                                    const uint8_t             *value);

static std::string  escapeSplChar(const char                  *inMsgBuf);
static uint8_t*     escapeSplChar(const uint8_t               *inMsgBuf,
                                  uint32_t                    &outLength);

static std::string  msgHeaderEnumToString(fsm_request_type_e enumVal);
static std::string  dataFormatEnumToString(data_format_e enumVal);

/**
 * @desc This method overload the = (equal to) operator of FSMXmlReq
 *       class. This method does a deep copy of the source FSMXmlReq
 *       _xmlMsgBuf to destination.
 *
 *       NOTE : The method allocates memory for _xmlMsgBuf of destination
 *              object. This memory is freed once the destructor of the
 *              destination object is called. Care must be given so that
 *              destructor is invoked on the purpose of the destination object
 *              is done.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  src             Reference to source object of FSMXmlReq type.
 *
 * @return     FSMXmlReq       Reference to object of FSMXmlReq type. Reference
 *                             is returned so that statment can be chained.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq& FSMXmlReq::operator= (const FSMXmlReq &src)
{
    ///Check whether source and destinations are same.
    if (this == &src ) {
        return *this;
    }
    ///Check if _xmlMsgBuf is already pointing to
    ///some memory location. In case yes, free the
    ///memory to avoid memory leak. I am banking on the
    ///fact that I initialize the _xmlMsgBuf to NULL
    ///during creation of an object.
    if ( NULL != _xmlMsgBuf ) {
        free(_xmlMsgBuf);
        _xmlMsgBuf    = NULL;
        _xmlMsgLength = 0;
        _bufUsed      = 0;
    }

    ///Do the actual copy by allocating and mempcying the
    ///source content.
    _xmlMsgBuf = (uint8_t *) malloc (src.getXmlMsgLength() *
                                     sizeof(uint8_t));
    ///Do the memcpy from the source object.
    memcpy(_xmlMsgBuf, src.getXmlMsgBuf(), src.getXmlMsgLength());
    _xmlMsgLength = src.getXmlMsgLength();
    _bufUsed = _xmlMsgLength;

    return (*this);

}

/**
 * @desc This method is the copy constructor of FSMXmlReq class.
 *       The constructor does a deep copy of the source FSMXmlReq
 *       _xmlMsgBuf to destination.
 *
 *       NOTE : The method allocates memory for _xmlMsgBuf of destination
 *              object. This memory is freed once the destructor of the
 *              destination object is called. Care must be given so that
 *              destructor is invoked on the purpose of the destination object
 *              is done.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  src             Reference to source object of FSMXmlReq type.
 *
 * @return     None            Constructor doesn't return in C++.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq::FSMXmlReq(const FSMXmlReq &src)
{
    ///Do the actual copy by allocating and mempcying the
    ///source content.
    _xmlMsgBuf = (uint8_t *) malloc ((src.getXmlMsgLength()) *
                                     sizeof(uint8_t));

    ///Do the memcpy from the source object.
    memcpy(_xmlMsgBuf, (src.getXmlMsgBuf()), (src.getXmlMsgLength()));
    _xmlMsgLength = src.getXmlMsgLength();
    _bufUsed = _xmlMsgLength;
}

/**
 * @desc This method overload the += operator for FSMXmlReq. += operator
 *       allocates more memory and append the source _xmlMsgBuf with the
 *       destination object. It also increment the _xmlMsgLength and
 *       _bufUsed accordingly.
 *
 *       NOTE : The method re-allocates memory for _xmlMsgBuf of destination
 *              object. This memory is freed once the destructor of the
 *              destination object is called. Care must be given so that
 *              destructor is invoked on the purpose of the destination object
 *              is done.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  src             Reference to source object of FSMXmlReq type.
 *
 * @return     FSMXmlReq       Reference to an object of FSMXmlReq type.
 *                             Reference is returned so that statment can be
 *                             chained.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq& FSMXmlReq::operator+=(const FSMXmlReq &src)
{
    Result_t    Result   = RESULT_SUCCESS;
    uint8_t     *tempBuf = NULL;
    ///Calculate new memory requirement for the
    ///destination object. This should be contain
    ///existing(destination) plus the source object
    ///size.
    ChkMemFatal(tempBuf = (uint8_t *) realloc(_xmlMsgBuf,(((_xmlMsgLength) +
                                                src.getXmlMsgLength()) *
                                                sizeof(uint8_t))));
    _xmlMsgBuf = tempBuf;

    ///Copy the new content.
    memcpy(_xmlMsgBuf + _xmlMsgLength, src.getXmlMsgBuf(),
           src.getXmlMsgLength());

    _xmlMsgLength += src.getXmlMsgLength();
    _bufUsed       = _xmlMsgLength;

    return(*this);
}

/**
 * @desc This method overload the += operator for FSMXmlReq. += operator
 *       allocates more memory and append the source string with the
 *       destination object. It also increment the _xmlMsgLength and
 *       _bufUsed accordingly.
 *
 *       NOTE : The method re-allocates memory for _xmlMsgBuf of destination
 *              object. This memory is freed once the destructor of the
 *              destination object is called. Care must be given so that
 *              destructor is invoked on the purpose of the destination object
 *              is done.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  src             Reference to source object of std::string type.
 *
 * @return     FSMXmlReq       Reference to an object of FSMXmlReq type.
 *                             Reference is returned so that statment can be
 *                             chained.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq& FSMXmlReq::operator+=(const std::string &src)
{
    Result_t    Result   = RESULT_SUCCESS;
    uint8_t     *tempBuf = NULL;

    ///Calculate new memory requirement for the
    ///destination object. This should be contain
    ///existing(destination) plus the source object
    ///size.
    ChkMemFatal(tempBuf = (uint8_t *) realloc(_xmlMsgBuf, (((_xmlMsgLength) +
                                              src.length()) *
                                              sizeof(uint8_t))));
    _xmlMsgBuf = tempBuf;

    ///Copy the new content.
    memcpy(_xmlMsgBuf + _xmlMsgLength, src.data(),
           src.length());

    _xmlMsgLength += src.length();
    _bufUsed       = _xmlMsgLength;

    return(*this);
}

/**
 * @desc This method overload the + operator. The + operator is overloaded
 *       to take two reference of FSMXmlReq type. It returns and object of
 *       FSMXmlReq type.
 *
 *       Scope : Extern (Can be called from functions outside the scope of
 *               this file).
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  first           Reference to first object of FSMXmlReq type.
 * @param[in]  second          Reference to second object of FSMXmlReq type.
 *
 * @return     FSMXmlReq       An object of FSMXmlReq type.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq operator+(const FSMXmlReq &first, const FSMXmlReq &second)
{
    FSMXmlReq       tempXmlReq = first;

    tempXmlReq+=second;

    return (tempXmlReq);
}

/**
 * @desc This method overload the + operator. The + operator is overloaded
 *       to take two references, first one of std::string type and the other
 *       one of FSMXmlReq type.
 *
 *       Scope : Extern (Can be called from functions outside the scope of
 *               this file).
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  first           Reference to first object of std::string type.
 * @param[in]  second          Reference to second object of FSMXmlReq type.
 *
 * @return     FSMXmlReq       An object of FSMXmlReq type.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq operator+(const std::string &first, const FSMXmlReq &second)
{
    FSMXmlReq       tempXmlReq = second ;
    FSMXmlReq       tempXmlReq2;

    tempXmlReq2 += first;

    tempXmlReq2 += tempXmlReq;
    return (tempXmlReq2);
}

/**
 * @desc This method overload the + operator. The + operator is overloaded
 *       to take two references, first one of FSMXmlReq type and the other
 *       one of std::string type.
 *
 *       Scope : Extern (Can be called from functions outside the scope of
 *               this file).
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  first           Reference to first object of FSMXmlReq type.
 * @param[in]  second          Reference to second object of std::string type.
 *
 * @return     FSMXmlReq       An object of FSMXmlReq type.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

FSMXmlReq operator+(const FSMXmlReq &first, const std::string &second)
{
    FSMXmlReq       tempXmlReq = first;

    tempXmlReq += second;
    return (tempXmlReq);
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       allocates 2K memory for storing XML message. The memory is
 *       allocated for _xmlMsgBuf pvt. member. This method also appends
 *       _xmlMsgBuf with the header passed as argument.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  header pointer to header string.
 *
 * @return     0      Success.
 * @return     < 0    Failure.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

Result_t FSMXmlReq::startXml(const char *header)
{
    Result_t                   Result = RESULT_SUCCESS;
    std::stringstream          xmlElement;
    const char                *elementChar;

    ///Allocate 2K memory memory space to start with.
    ChkMemFatal(_xmlMsgBuf = (uint8_t *) malloc(2048 * sizeof(uint8_t)));

    _xmlMsgLength = 2048;

    xmlElement << header;

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    ///Convert string to header.
    convStringToByte(elementChar);

    return Result;
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       frees unused memory allocated for _xmlMsgBuf. Accordingly the
 *       _xmlMsgLength is changed.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  void No parameters are passed to this member function.
 *
 * @return     0      Success.
 * @return     < 0    Failure.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

Result_t FSMXmlReq::wrapXml(void)
{
    Result_t                   Result = RESULT_SUCCESS;
    std::stringstream          xmlElement;
    uint8_t                   *tempPtr;

    ///At this point, Check if we have used
    ///the all the pre allocated space.
    if ( (_xmlMsgLength - _bufUsed) > 0 ) {
        ChkMemFatal(tempPtr = (uint8_t *) realloc(_xmlMsgBuf,
                                (_bufUsed * (sizeof(uint8_t))) ));
        _xmlMsgBuf = tempPtr;
        _xmlMsgLength = _bufUsed;
    }

    return Result;
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       check whether the buffer left in _xmlMsgBuf is sufficient for
 *       requested sized. Otherwise, memory is allocated in 1k chunks.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  header pointer to header string.
 *
 * @return     0      Success.
 * @return     < 0    Failure.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

Result_t FSMXmlReq::checkAndRealloc( uint32_t      reqSize)
{
    uint8_t      *tempBuf;
    Result_t      Result = RESULT_SUCCESS;

    ///Make sure I have sufficient memory to left
    while ( (_xmlMsgLength - _bufUsed) < reqSize ) {
        ///Try allocating 1k of space and check.
        ChkMemFatal(tempBuf = (uint8_t *) realloc(_xmlMsgBuf,
                           (_xmlMsgLength + 1024) * (sizeof(uint8_t))));
        _xmlMsgBuf = tempBuf;
        _xmlMsgLength += 1024;
    }
    return Result;
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       appends the characters string (null terminated) to _xmlMsgBuf.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  header pointer to header string.
 *
 * @return     0      Success.
 * @return     < 0    Failure.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

void FSMXmlReq::convStringToByte(const char   *msgString)
{
    ///Calculate the size of the header.
    uint32_t   stringSize = strlen(msgString);
    uint32_t   counter    = 0;

    ///Check the size of the buffer left.
    checkAndRealloc(stringSize);
    while ( counter < stringSize ) {
         _xmlMsgBuf[_bufUsed] = *msgString++;
         ++_bufUsed;
         ++counter;
    }
    return;
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       appends the utf8 character string (null terminated) to _xmlMsgBuf.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  header pointer to header string.
 *
 * @return     0      Success.
 * @return     < 0    Failure.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

void FSMXmlReq::addUtf8ToByte(uint8_t      *utf8MsgPtr,
                              uint32_t      utf8MsgLength)
{
    uint32_t   counter = 0;
    ///Make sure we have sufficient space.
    checkAndRealloc(utf8MsgLength);

    while (counter < utf8MsgLength) {
         _xmlMsgBuf[_bufUsed] = *utf8MsgPtr++;
         ++_bufUsed;
         ++counter;
    }
    return;
}

/**
 * @desc This method is a public method in FSMXmlReq class. This method
 *       prints the ascii representation of the utf8 buffer pointed by
 *       _xmlMsgBuf.
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  void Doesn't take any value.
 *
 * @return     void Doesn't return any value.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

void FSMXmlReq::printAsciiXmlMsg(void) const
{
    ///FSMXmlReq is not a null terminated buffer. To print
    ///the  buffer we must first null terminate so that
    ///print routines will work fine.
    uint8_t *printBuf = (uint8_t *) malloc((_xmlMsgLength + 1) *
                                           sizeof(uint8_t));
    strncpy((char *) printBuf, (char *)_xmlMsgBuf, _xmlMsgLength);
    printBuf[_xmlMsgLength] = '\0';

    printf("The value of buffer length is %d\n",_xmlMsgLength);
    printf("The buffer is \n %s\n", (char *)printBuf);
    ///Free the memory.
    free(printBuf);
}

/**
 * @desc This method appends start tag to _xmlMsgBuf of xmlReq.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with start tag.
 * @param[in]   xmlTag   Pointer to start tag.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addStartTag(FSMXmlReq &xmlReq, const char *xmlTag)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    ///Convert element to utf8 string
    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends end tag to _xmlMsgBuf of xmlReq.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with end tag.
 * @param[in]   xmlTag   Pointer to end Tag.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addEndTag(FSMXmlReq &xmlReq, const char *xmlTag)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "</" << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    ///Convert element to utf8 string
    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       signed 32-bit integer type.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    Signed 32bit integer value.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq    &xmlReq,
                            const char   *xmlTag,
                            const int32_t value)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">" << value << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();


    ///Convert element to utf8 string
    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       unsigned 32-bit integer type.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    unsigned 32bit integer value.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq      &xmlReq,
                            const char     *xmlTag,
                            const uint32_t  value)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">" << value << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       unsigned 64-bit integer type.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    unsigned 64-bit integer value.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq      &xmlReq,
                            const char     *xmlTag,
                            const uint64_t  value)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">" << value << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       signed 64-bit integer type.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    signed 64-bit integer value.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq      &xmlReq,
                            const char     *xmlTag,
                            const int64_t   value)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">" << value << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       boolean type.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    boolean value.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq    &xmlReq,
                            const char   *xmlTag,
                            const bool    value)
{
    std::stringstream          xmlElement;
    const char                *elementChar;

    xmlElement << "<" << xmlTag << ">" << value << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    ///Convert string to header.
    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       signed character type. The special characters in the
 *       array pointed by the value pointer is escaped before
 *       it is added to _xmlMsgBuf pointer.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    pointer to array of signed character.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq    &xmlReq,
                            const char   *xmlTag,
                            const char   *value)
{
    std::string          escXmlElement;
    std::stringstream    xmlElement;
    const char          *elementChar;

    ///Need to escape the special characters.
    escXmlElement = escapeSplChar(value);

    xmlElement << "<" << xmlTag << ">" << escXmlElement << "</"
               << xmlTag << ">";

    const std::string tempStr(xmlElement.str());
    elementChar = tempStr.c_str();

    ///Convert string to header.
    xmlReq.convStringToByte(elementChar);
}

/**
 * @desc This method appends node (consists of start tag, value,
 *       end tag) to the _xmlMsgBuf pointer. The value is of
 *       utf8 character type. The special characters in the
 *       utf8 array pointed by the value pointer is escaped before
 *       it is added to _xmlMsgBuf pointer.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[out]  xmlReq   Reference to xmlReq whose _xmlMsgBuf will be
 *                       appended with xml node.
 * @param[in]   xmlTag   Pointer to xml tag string. This is used to
 *                       construct the start and end xml tag.
 * @param[in]   value    pointer to array of utf8 character.
 *
 * @return     void     This method doesn't return anything.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static void addTagWithValue(FSMXmlReq     &xmlReq,
                            const char    *xmlTag,
                            const uint8_t *value)
{
    uint8_t             *utf8Ptr;
    std::stringstream    startTag;
    std::stringstream    endTag;
    uint32_t             outLength;
    const char          *elementChar;

    ///Need to escape the UTF-8 block. For this find out
    ///how much of space do we need.
    utf8Ptr = escapeSplChar(value, outLength);

    startTag << "<" << xmlTag << ">" ;

    const std::string tempStartTag(startTag.str());
    elementChar = tempStartTag.c_str();

    xmlReq.convStringToByte(elementChar);

    xmlReq.addUtf8ToByte(utf8Ptr, outLength);

    ///Now add the closing tag.
    endTag << "</" << xmlTag << ">";

    const std::string tempEndTag(endTag.str());
    elementChar = tempEndTag.c_str();

    ///Convert string to header.
    xmlReq.convStringToByte(elementChar);
    ///Make sure we don't leak memory!
    free(utf8Ptr);
}

/**
 * @desc This method escapes the special character present in
 *       signed character array pointed by the str.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in] str         Pointer pointing to array of signed chars.
 *
 * @return    std::string std::string object with special chars escaped.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static std::string escapeSplChar(const char *str)
{
    ///Below will contain the escaped string
    std::string escXmlElement;
    ///Find the number of elements in the string.
    uint32_t    strLength = strlen(str);
    uint32_t    counter   = 0;

    ///Budget for number of special chars.
    while ( counter < strLength ) {
        if ( *str == '<' ) {
            escXmlElement += '&';
            escXmlElement += 'l';
            escXmlElement += 't';
            escXmlElement += ';';
        }
        else if ( *str == '>' ) {
            escXmlElement += '&';
            escXmlElement += 'g';
            escXmlElement += 't';
            escXmlElement += ';';
        }
        else if ( *str == '&' ) {
            escXmlElement += '&';
            escXmlElement += 'a';
            escXmlElement += 'm';
            escXmlElement += 'p';
            escXmlElement += ';';
        }
        else if ( *str == '"' ) {
            escXmlElement += '&';
            escXmlElement += 'q';
            escXmlElement += 'u';
            escXmlElement += 'o';
            escXmlElement += 't';
            escXmlElement += ';';
        }
        else if ( *str == '\'') {
            escXmlElement += '&';
            escXmlElement += 'a';
            escXmlElement += 'p';
            escXmlElement += 'o';
            escXmlElement += 's';
            escXmlElement += ';';
        }
        else {
            escXmlElement += *str;
        }
        ///Now increment the reference counter for str
        ++str;
        ++counter;
    }
    return(escXmlElement);
}

/**
 * @desc This method escapes the special character present in
 *       utf8 character array(null terminated) pointed by the inMsg.
 *
 *       Scope : static (Accessible from function within this file.)
 *
 *       Thread Safety : This routine is re-entrant.
 *
 * @param[in]  inMsg     pointer to utf8 character array.
 * @param[out] outLength Reference to output length of the escaped utf8i
 *                       string.
 *
 * @return    uint8_t    Pointer to array of utf8 characters which is
 *                       of uint8_t type.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

static uint8_t * escapeSplChar (const uint8_t  *inMsg, uint32_t &outLength)
{
    const uint8_t    *baseMsgPtr   = inMsg;
    uint8_t          *baseOutMsgPtr = NULL;
    uint8_t          *outMsgPtr    = NULL;
    uint32_t          counter      = 0;
    uint32_t          inMsgLength  = strlen((char *)inMsg);
    ///Start with the same lenght and increase
    ///whenever we see a special character.
    uint32_t          escMsgLength = inMsgLength;
    Result_t          Result = RESULT_SUCCESS;

    ///Do the budgeting for calculating the memory requirement
    ///for escaped utf8 message.
    while ( counter < inMsgLength ) {
        if ( *inMsg == '<' ) {
            escMsgLength += 3;
        }
        else if ( *inMsg == '>' ) {
            escMsgLength += 3;
        }
        else if ( *inMsg == '&' ) {
            escMsgLength += 4;
        }
        else if ( *inMsg == '"' ) {
            escMsgLength += 5;
        }
        else if ( *inMsg == '\'') {
            escMsgLength += 5;
        }
        ++counter;
        ++inMsg;
    }
    ///Now that budgeting is done, allocate memory for escaped
    ///string.
    ChkMemFatal(outMsgPtr = (uint8_t *) malloc(escMsgLength * (sizeof(uint8_t))));
    baseOutMsgPtr = outMsgPtr;

    ///Start from the beginning again!!
    inMsg   = baseMsgPtr;
    counter = 0;

    ///Now Populate the outMsgPtr
    while ( counter < inMsgLength ) {
        if ( *inMsg == '<' ) {
            *outMsgPtr++ = '&';
            *outMsgPtr++ = 'l';
            *outMsgPtr++ = 't';
            *outMsgPtr++ = ';';
        }
        else if ( *inMsg == '>' ) {
            *outMsgPtr++ = '&';
            *outMsgPtr++ = 'g';
            *outMsgPtr++ = 't';
            *outMsgPtr++ = ';';
        }
        else if ( *inMsg == '&' ) {
            *outMsgPtr++ = '&';
            *outMsgPtr++ = 'a';
            *outMsgPtr++ = 'm';
            *outMsgPtr++ = 'p';
            *outMsgPtr++ = ';';
        }
        else if ( *inMsg == '"' ) {
            *outMsgPtr++ = '&';
            *outMsgPtr++ = 'q';
            *outMsgPtr++ = 'u';
            *outMsgPtr++ = 'o';
            *outMsgPtr++ = 't';
            *outMsgPtr++ = ';';
        }
        else if ( *inMsg == '\'') {
            *outMsgPtr++ = '&';
            *outMsgPtr++ = 'a';
            *outMsgPtr++ = 'p';
            *outMsgPtr++ = 'o';
            *outMsgPtr++ = 's';
            *outMsgPtr++ = ';';
        }
        else {
            *outMsgPtr++ = *inMsg;
        }
        ++inMsg;
        ++counter;
    }
    outLength = escMsgLength;
    return(baseOutMsgPtr);
}

/*HandshakeResp::HandshakeResp(const uint32_t vserver, const char* session,
                             const char    *policy, const char *supportedVers)
{
    _vserverId = vserver;
    strncpy(_sessionId, session, MAX_SESSION_ID_LEN);
    _sessionId[MAX_SESSION_ID_LEN] = '\0';
    strncpy(_policyName, policy, MAX_POLICY_NAME_LEN);
    _policyName[MAX_POLICY_NAME_LEN] = '\0';
    strncpy(_supportedVersions, supportedVers, MAX_VERSION_LEN);
    _supportedVersions[MAX_VERSION_LEN] = '\0';
}*/

HandshakeResp::HandshakeResp(const char *vserverUUID, const char *session, const char *policy, const char *supportedVers)
{
    printf("**************\n%s***************\n",vserverUUID);
    strncpy(_VsUUID, vserverUUID, MAX_POLICY_NAME_LEN);
    _VsUUID[MAX_SESSION_ID_LEN] = '\0';
    strncpy(_sessionId, session, MAX_SESSION_ID_LEN);
    _sessionId[MAX_SESSION_ID_LEN] = '\0';
    strncpy(_policyName, policy, MAX_POLICY_NAME_LEN);
    _policyName[MAX_POLICY_NAME_LEN] = '\0';
    strncpy(_supportedVersions, supportedVers, MAX_VERSION_LEN);
    _supportedVersions[MAX_VERSION_LEN] = '\0';

}

/**
 * @desc This routine populate the XML request for handshake notification.
 *       A handshake notification consists of following elements :
 *        - Vserver ID
 *        - Policy Name.
 *        - Session ID.
 *        - ProtVersions (This could be a list of versions supported by
 *          storage appliance.
 *       This method on completion populate the XML buffer  for
 *       handshake notification pointed by _xmlMsgBuf pointer in
 *       FSMXmlReq class.
 *
 * @param[in]  void No parameters are passed to this function.
 *
 * @return     void No parameters are returned from this function.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

void  HandshakeResp::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void) startXml(header);
    addStartTag((*this), "HandshakeResp");
      addTagWithValue((*this), "VsUUID", _VsUUID);
      //addTagWithValue((*this), "VsId", _vserverId);

      addTagWithValue((*this), "PolicyName", _policyName);
      addTagWithValue((*this), "SessionId", _sessionId);
      addTagWithValue((*this), "ProtVersion", _supportedVersions);
    addEndTag((*this), "HandshakeResp");
    (void) wrapXml();
}

/**
 * @desc This routine populate the XML request for handshake notification.
 *       A handshake notification consists of following elements :
 *        - Vserver ID
 *        - Policy Name.
 *        - Session ID.
 *        - ProtVersions (This could be a list of versions supported by
 *          storage appliance.
 *       This method on completion returns an object of FSMXmlReq which
 *       holds _xmlMsgBuf pointer pointing to XML message buffer for
 *       handshake notification.
 *
 *       NOTE : It is the responsibility of the caller to delete the
 *              dynamically allocated object.
 *
 *       Scope : Extern (Accessible from function outside this file.)
 *
 * @param[in]  vserverId  Vserver Id for which handshake request is being
 *                        sent.
 * @param[in]  session    Session id for which handshake request is being
 *                        sent.
 * @param[in]  policy     Policy for which handshake request is being sent.
 *
 * @return     FSMXmlReq* Pointer to newly allocated object which holds the
 *                        _xmlMsgBuf.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/26/2011
 *
 */

/*FSMXmlReq*   populateXmlHandshakeResp(const uint32_t    vserverId,
                                      const char       *session,
                                      const char       *policy,
                                      const char       *supportedVers)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *handshakeResp = new HandshakeResp(vserverId,
                                                 session,
                                                 policy,
                                                 supportedVers);

    ///Now call populate XML request.
    handshakeResp->populateXmlReq();

    return (handshakeResp);
}*/


FSMXmlReq*   populateXmlHandshakeResp(const char       *vserverUUID,
                                      const char       *session,
                                      const char       *policy,
                                      const char       *supportedVers)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *handshakeResp = new HandshakeResp(vserverUUID,
                                                 session,
                                                 policy,
                                                 supportedVers);

    ///Now call populate XML request.
    handshakeResp->populateXmlReq();

    return (handshakeResp);
}



/**
 * @desc This routine populate the XML request for message header.
 *       This method on completion returns an object of FSMXmlReq which
 *       holds _xmlMsgBuf pointer pointing to XML message buffer for
 *       message header.
 *
 *       NOTE : It is the responsibility of the caller to delete the
 *              dynamically allocated object.
 *
 *       Scope : Extern (Accessible from function outside this file.)
 *
 * @param[in]  msgType      The message type of the payload followed by the
 *                          message header.
 * @param[in]  length       The length of the payload message.
 * @param[in]  dataFormat   The data format of the payload.
 *
 * @return     FSMXmlReq* Pointer to newly allocated object which holds the
 *                        _xmlMsgBuf.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/26/2011
 *
 */

FSMXmlReq*   populateXmlHeaderMsg(const fsm_request_type_e msgType,
                                  const uint64_t           length,
                                  const data_format_e      dataFormat)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *headerReq = new MessageHeader(msgType,
                                             length,
                                             dataFormat);
    ///Now call populate XML request.
    headerReq->populateXmlReq();

    return (headerReq);
}

/**
 * @desc This method construct an XML message for Header.
 *       Any message sent it FPolicy server is preceded by
 *       a header. A header contains following important
 *       elements :
 *          - Notification Type
 *          - Content Length of the payload.
 *          - Data Format.
 *       A header is separate from the payload by two consecutive
 *       "\r\n\r\n".
 *       This method on completion populate the XML buffer  for
 *       message header pointed by _xmlMsgBuf pointer in
 *       FSMXmlReq class.
 *
 * @param[in]  void No parameters are passed to this function.
 *
 * @return     void No parameters are returned from this function.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/21/2011
 *
 */

void MessageHeader::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void)startXml(header);
    addStartTag((*this), "Header");
      addTagWithValue((*this),"NotfType", (msgHeaderEnumToString(_msgType)).c_str());
      addTagWithValue((*this),"ContentLen", _contentLength);
      addTagWithValue((*this),"DataFormat",(dataFormatEnumToString(_dataFormat)).c_str());
    addEndTag((*this), "Header");
    (void)wrapXml();
}

/**
 * @desc This method is the constructor of AlertNotification.
 *
 * @param[in]  sessionId  Session Id to be sent in alert notfication.
 * @param[in]  alertMsg   Alert msg which will be sent in alert notification.
 * @param[in]  severity   Severity of the alert notification message.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/20/2011
 *
 */

AlertNotification::AlertNotification(const char       *sessionId,
                                     const char       *alertMsg,
                                     const uint32_t    severity)
{
    _severity = severity;
    strncpy(_sessionId, sessionId, MAX_SESSION_ID_LEN);
    _sessionId[MAX_SESSION_ID_LEN] = '\0';
    strncpy(_alertMsg, alertMsg, MAX_ALERT_MSG_LEN);
    _alertMsg[MAX_ALERT_MSG_LEN] = '\0';
}

/**
 * @desc This method construct an XML message for Alert Message
 *       which is sent to FPolicy Server. The Alert message has
 *       following important element :
 *        - Session ID
 *        - Severity
 *        - Alert Message String.
 *       This method on completion populate the XML buffer  for
 *       Alert notification pointed by _xmlMsgBuf pointer in
 *       FSMXmlReq class.
 *
 * @param[in]  void No parameters are passed to this function.
 *
 * @return     void No parameters are returned from this function.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/19/2011
 *
 */

void  AlertNotification::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void)startXml(header);
    addStartTag((*this), "Alert");
      addTagWithValue((*this), "SessionId", _sessionId);
      addTagWithValue((*this), "Severity", _severity);
      addTagWithValue((*this),"AlertMsg", _alertMsg);
    addEndTag((*this), "Alert");
    (void)wrapXml();
}

/**
 * @desc This routine populate the XML request for alert notification.
 *       This method on completion returns an object of FSMXmlReq which
 *       holds _xmlMsgBuf pointer pointing to XML message buffer for
 *       alert notification.
 *
 *       NOTE : It is the responsibility of the caller to delete the
 *              dynamically allocated object.
 *
 *       Scope : Extern (Accessible from function outside this file.)
 *
 * @param[in]  sessionId    Session id for which alert message is sent.
 * @param[in]  alertMsg     Alert message string for which alert notification
 *                          is sent.
 * @param[in]  severity     Severity of the alert notification.
 *
 * @return     FSMXmlReq* Pointer to newly allocated object which holds the
 *                        _xmlMsgBuf.
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/26/2011
 *
 */

FSMXmlReq*   populateXmlAlertMsg(const char       *sessionId,
                                 const char       *alertMsg,
                                 const uint32_t    severity)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *alertReq = new AlertNotification(sessionId,
                                                alertMsg,
                                                severity);
    ///Now call populate XML request.
    alertReq->populateXmlReq();

    return (alertReq);
}

FSMXmlReq* populateXmlNotificationResp(const uint64_t reqId,
                                       const unsigned char *reqType,
                                       const uint32_t resp)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *notResp = new NotificationResp(reqId,
                                              reqType,
                                              resp);
    ///Now call populate XML request.
    notResp->populateXmlReq();

    return (notResp);
}

NotificationResp::NotificationResp(const uint64_t reqId,
                                   const unsigned char *reqType,
                                   const uint32_t resp)
{
    _reqId = reqId;
    strncpy((char *)_reqType,(char *) reqType, MAX_REQ_TYPE_LEN);
    _reqType[MAX_REQ_TYPE_LEN] = '\0';
    _resp = resp;
}

void  NotificationResp::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void)startXml(header);
    //addStartTag((*this), "FscreenResp");
    addStartTag((*this), "FscreenResp");
      addTagWithValue((*this), "ReqId", _reqId);
      addTagWithValue((*this), "ReqType", _reqType);
      addTagWithValue((*this),"NotfResp", _resp);
    addEndTag((*this), "FscreenResp");
    (void)wrapXml();
}

FSMXmlReq* populateXmlBackPressure(const unsigned char *sessionId,
                                   const bool   apply)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *backPressureReq = new BackPressure(sessionId,
                                                  apply);

    ///Now call populate XML request.
    backPressureReq->populateXmlReq();

    return (backPressureReq);
}

BackPressure::BackPressure(const unsigned char *sessionId,
                           const bool   apply)
{
    _apply = apply;
    strncpy((char *)_sessionId,(char *) sessionId, MAX_SESSION_ID_LEN);
    _sessionId[MAX_SESSION_ID_LEN] = '\0';
}

void  BackPressure::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void)startXml(header);
    addStartTag((*this), "BackPressure");
      addTagWithValue((*this), "SessionId", _sessionId);
      addTagWithValue((*this),"Apply", _apply);
    addEndTag((*this), "BackPressure");
    (void)wrapXml();
}

FSMXmlReq* populateStatusResponse(const uint64_t reqId,
                                  const unsigned char *reqType,
                                  const uint32_t resp)
{
    ///Create a FSMXmlReq object.
    FSMXmlReq *statusResp = new StatusResp(reqId,
                                           reqType,
                                           resp);

    ///Now call populate XML request.
    statusResp->populateXmlReq();

    return (statusResp);
}

StatusResp::StatusResp(const uint64_t reqId,
                       const unsigned char *reqType,
                       const uint32_t resp)
{
    _reqId = reqId;
    strncpy((char *)_reqType,(char *) reqType, MAX_REQ_TYPE_LEN);
    _reqType[MAX_REQ_TYPE_LEN] = '\0';
    _statusResp = resp;
}

void  StatusResp::populateXmlReq(void)
{
    const char  *header = "<?xml version=\"1.0\"?>";
    (void)startXml(header);
    addStartTag((*this), "FscreenStatusResp");
      addTagWithValue((*this), "ReqId", _reqId);
      addTagWithValue((*this), "ReqType", _reqType);
      addTagWithValue((*this), "Resp", _statusResp);
    addEndTag((*this), "FscreenStatusResp");
    (void)wrapXml();
}

/**
 * @desc This routine converts message header id type enum
 *       to string.
 *
 *       Scope : Static (Can be called only by functions
 *               present in this file.
 *
 *       Thread Safety : Re-entrant.
 *
 * @param[in]  enumVal      message header type enum value.
 *
 * @return     string       string object
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/27/2011
 *
 */

static std::string  msgHeaderEnumToString(fsm_request_type_e enumVal)
{
    std::string msgHeaderType;

    switch(enumVal) {
        case NEGO_MSG_REQ :
        {
            msgHeaderType = "NEGO_REQ";
            break;
        }
        case NEGO_MSG_RESP :
        {
            msgHeaderType = "NEGO_RESP";
            break;
        }
        case FILE_NOTIFY_REQ :
        {
            msgHeaderType = "SCREEN_REQ";
            break;
        }
        case FILE_NOTIFY_RESP :
        {
            msgHeaderType = "SCREEN_RESP";
            //msgHeaderType = "FILE_NOTIFY_RESP";
            break;
        }
        case VOL_NOTIFY :
        {
            msgHeaderType = "VOL_NOTFICATION";
            break;
        }
        case FILE_NOTIFY_CANCEL_REQ :
        {
            msgHeaderType = "SCREEN_CANCEL";
            break;
        }
        case STATUS_QUERY_REQ :
        {
            msgHeaderType = "STATUS_QUERY_REQ";
            break;
        }
        case STATUS_QUERY_RESP :
        {
            msgHeaderType = "STATUS_QUERY_RESP";
            break;
        }
        case BACKBACK_RESSURE_APPLY_REQ :
        {
            msgHeaderType = "BACK_PRESSURE_APPLY";
            break;
        }
        case BACK_PRESSURE_REMOVE_REQ :
        {
            msgHeaderType = "BACK_PRESSURE_REM";
            break;
        }
        case KEEP_ALIVE_REQ :
        {
            msgHeaderType = "KEEP_ALIVE";
            break;
        }
        case ALERTS :
        {
            msgHeaderType = "ALERT_MSG";
            break;
        }
        default :
        {
            msgHeaderType = "UNKNOWN";
            break;
        }
    }
    return msgHeaderType;
}

/**
 * @desc This routine converts data format type enum
 *       to string.
 *
 *       Scope : Static (Can be called only by functions
 *               present in this file.
 *
 *       Thread Safety : Re-entrant.
 *
 * @param[in]  enumVal      message header type enum value.
 *
 * @return     string       string object
 *
 * @author Sudip Kumar Panda
 *
 * @date 12/31/2011
 *
 */

static std::string  dataFormatEnumToString(data_format_e enumVal)
{
    std::string dataFormatType;

    switch(enumVal) {
        case FORMAT_XML :
        {
            dataFormatType = "XML";
            break;
        }
        default :
        {
            dataFormatType = "UNKNOWN";
            break;
        }
    }
    return dataFormatType;
}

void FPS_Notification::enqueueNotficationObj(void)
{
    ///Referring to the global notification task
    ///object which holds the reponsibility of
    ///enqueuing the request.
    (void)gFpsNotfObj.enqueueNotification(this);
}

int FPS_Notification::makeFpsCall(void)
{
    int  retVal = 0;
    retVal = _connPtr->processFSMRequest(_msgBuf, _msgLen);
    return(retVal);
}

FPS_NotificationTask::FPS_NotificationTask(void)
{
    memset(_workerThreadsId, 0, sizeof(_workerThreadsId));
    _shutdown = false;
}

int32_t FPS_NotificationTask::enqueueNotification(
        FPS_Notification *newel)
{
    int32_t   result = RESULT_SUCCESS;
    result = _fpsNotificationObj.enqueueNotfObj(newel);

    if (result != RESULT_SUCCESS) {
        fprintf (stderr, "%s %d: Error in enqueuing the notification to "
                "FPS notification queue. result=%d\n",
                __FILE__, __LINE__, result);
    }

    return(result);
}

void FPS_NotificationTask::startNotfWorkerThreads(void)
{
    uint32_t count = 0;
    int32_t  err = 0;

    for (count = 0; count < FPS_NOTIFICATION_NUM_THREADS; count++)
    {
        ///Note that pthread_create can't take a class function so the
        ///function called in pthread_create must be a static class
        ///function or a C function. Otherwise, build will fail.
        err = pthread_create(&_workerThreadsId[count], NULL, workEntryFunc,
                             this);
        if (err != 0) {
            fprintf (stderr, "%s %d: Failed to create threads for "
                    "FPS notification framework. result=%d\n",
                    __FILE__, __LINE__, err);
        }
    }
}


void FPS_NotificationTask::waitForNotfWorkerThreads(void)
{
    uint32_t count = 0;
    for (count =0; count < FPS_NOTIFICATION_NUM_THREADS; count++)
    {
        (void) pthread_join(_workerThreadsId[count], NULL);
    }
}

void FPS_NotificationTask::stopNotfWorkerThreads(void)
{
    fprintf (stderr, "Received shutdown request for "
            "server notification threads. thread_id=[0x%p]"
            " %s:%d\n", pthread_self(), __FILE__,__LINE__);
    _shutdown = true;
    _fpsNotificationObj.setShutdown();
}

void FPS_NotificationTask::run(void)
{
    FPS_Notification  *element = NULL;
    int32_t                result;

    fprintf (stderr, "Worker thread=0x%p for FPS "
            "notification framework is started. %s:%d\n",
            pthread_self(), __FILE__,__LINE__);

    while (true) {
        result = _fpsNotificationObj.dequeueNotfObj(&element);
        if (result < 0 || true == _shutdown) {
            fprintf (stderr, "Received shutdown request for "
                    "server notification threads. thread_id=[0x%p]"
                    " %s:%d\n", pthread_self(), __FILE__,__LINE__);
           return;
        }
        /// Call the makeRpc member function which is implemented by the
        /// provider. Take advantage of virtual function.
        result = element->makeFpsCall();

        if (result != 0) {
        fprintf (stderr, "FPS processing Failed. retStatus=%d  thread_id=[0x%p]"
                " %s:%d\n", result, pthread_self(), __FILE__,__LINE__);
        }
        ///Time to Delete the element to avoid memory leak!!!
        delete element;
        element = NULL;
    }
}

void FPS_NotificationList::setShutdown(void)
{
    ///No need to set _shutdown with a mutex locked since we
    ///are protecting the list and condition var and not the mutex.
    int retStatus = 0;
    _shutdown = true;

    retStatus = pthread_mutex_lock(&_notificationQueueMutex);
    if (retStatus != 0) {
        fprintf (stderr, "Failed to lock the mutex. retStatus=%d "
                " thread_id=[0x%p] %s:%d\n", retStatus,pthread_self(),
                __FILE__,__LINE__);
        return;
    }

    retStatus = pthread_cond_broadcast(&_workerCv);
    if (retStatus != 0) {
        fprintf (stderr, "Failed to send broadcast. retStatus=%d "
                " thread_id=[0x%p] %s:%d\n", retStatus,pthread_self(),
                __FILE__,__LINE__);
    }

    retStatus = pthread_mutex_unlock(&_notificationQueueMutex);
    if (retStatus != 0) {
        fprintf (stderr, "Failed to unlock the mutex. retStatus=%d "
                " thread_id=[0x%p] %s:%d\n", retStatus,pthread_self(),
                __FILE__,__LINE__);
        return;
    }
}

FPS_NotificationList::FPS_NotificationList()
{
   (void) pthread_mutex_init(&_notificationQueueMutex, NULL);
   (void) pthread_cond_init(&_workerCv, NULL);
   _workersWaiting = 0;
   _shutdown = false;
}

FPS_NotificationList::~FPS_NotificationList()
{
   (void) pthread_mutex_destroy(&_notificationQueueMutex);
   (void) pthread_cond_destroy(&_workerCv);
}

int32_t FPS_NotificationList::enqueueNotfObj(
         FPS_Notification *newElement)
{
    (void) pthread_mutex_lock(&_notificationQueueMutex);

    ///No point in enqueueing any item when the _shutdown
    ///flag is set to true. We allow the RDB call back thread
    ///to go without any issue.
    if (true == _shutdown) {
        (void) pthread_mutex_unlock(&_notificationQueueMutex);
        fprintf (stderr, "Received shutdown request for "
                "server notification threads. enqueueNotfObj()."
                " thread_id=[0x%p] %s:%d\n", pthread_self(),
                __FILE__,__LINE__);
        return(-1);
    }

    fprintf (stderr, "Enqueued notification request to"
            "server notification queue.dequeueNotfObj()."
            " thread_id=[0x%p] %s:%d\n", pthread_self(),
            __FILE__,__LINE__ );

    /// Add the element new element to the tail of the list.
    _notificationQueue.push_back(newElement);

    /// Don't want to un-necessarily use the pthread signalling.
    if (_workersWaiting > 0) {
        /// Wake up Guys, Don't feel bad, we are also working
        /// hard!
        (void) pthread_cond_signal(&_workerCv);
    }

    (void) pthread_mutex_unlock(&_notificationQueueMutex);

    return(RESULT_SUCCESS);
}

int32_t FPS_NotificationList::dequeueNotfObj(
        FPS_Notification **element)
{
    (void) pthread_mutex_lock(&_notificationQueueMutex);

    /// The below condition helps in handling suprious wake-ups.
    while (true == _notificationQueue.empty()) {
        if (true == _shutdown) {
            (void) pthread_mutex_unlock(&_notificationQueueMutex);
            fprintf (stderr, "Received shutdown request for"
                    "FPS notification thread. Returning from. "
                    "dequeueNotfObj(). thread_id=[0x%p] %s:%d\n",
                    pthread_self(),__FILE__,__LINE__);
            return(-1);
        }

        /// No work. Take rest. I envy.
        _workersWaiting++;
        (void) pthread_cond_wait(&_workerCv, &_notificationQueueMutex);
        _workersWaiting--;
    }

    /// We might have some entry in the queue but we want to shutdown
    /// in this case, it is upto the task class to handle but I don't
    /// see any harm in placing and extra check and return with error.
    if (true == _shutdown) {
        (void) pthread_mutex_unlock(&_notificationQueueMutex);
        fprintf (stderr, "Received shutdown request for"
                "FPS notification thread. Returning from. "
                "dequeueNotfObj(). thread_id=[0x%p] %s:%d\n",
                pthread_self(), __FILE__, __LINE__);

        return(-1);
    }

    *element = _notificationQueue.front();
    _notificationQueue.pop_front();
    (void) pthread_mutex_unlock(&_notificationQueueMutex);

    return(RESULT_SUCCESS);
}

