/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_server.cc
 *
 * @author Sudip Kumar Panda
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 * @brief This file contains sample code for communicating with NetApp
 *        storage appliance.
 */

#include "fps_server.h"
//#include <syslog.h>
#include "fps_notification.h"
#include "fps_external_engine.h"
#include <signal.h>
#include <sys/signal.h>


int32_t                       vsId;
char                          *polName;
extern int32_t                mode;
extern int32_t                isMutualAuth;
extern int32_t                FpServerPort;
extern int32_t                Response;
extern int32_t                sslAuthEnabled;
extern char                   *ciphers;
char                          *filename = NULL;
char                          *dirname  = NULL;
extern int32_t                delay;
extern std::string            sessionId;
extern int                    listenFdIpv4;
extern int                    listenFdIpv6;


void openLogfile(void);
void applyBackPressure(void);
void terminateProcess(void);
void removeBackPressure(void);
int32_t sendMsg(FSMXmlReq &xmlReqToSend);
void handler(int signal);
FPS_NotificationTask gFpsNotfObj;


void registerSignalHandler(void)
{
    struct sigaction new_action;
    memset(&new_action, 0, sizeof(new_action));
    sigemptyset(&new_action.sa_mask);
    new_action.sa_flags = SA_RESTART;
    new_action.sa_handler = handler;

    sigaction(SIGUSR1, &new_action, NULL);
    sigaction(SIGUSR2, &new_action, NULL);
    sigaction(SIGINT,  &new_action, NULL);
}

void handler(int signal)
{
    if (SIGUSR1 == signal) {
        applyBackPressure();
    }
    else if (SIGUSR2 == signal) {
        removeBackPressure();
    }
    else if (SIGINT == signal) {
        terminateProcess();
    }
    else {
        fprintf (stderr, "Unknown signal [%d] \n", signal);
    }
}

void applyBackPressure()
{
    int32_t   retval;
    ///Form a back pressure message.
    std::string separator("\n\n");
    std::string nullChar;
    nullChar += '\0';

#if 0
    FSMXmlReq *backPressure = populateXmlBackPressure((unsigned char*)sessionId.c_str(),
                                                      true);

    FSMXmlReq *backPressureHeader = populateXmlHeaderMsg(
                                          BACKBACK_RESSURE_APPLY_REQ,
                                          backPressure->getXmlMsgLength(),
                                          FORMAT_XML);
    FSMXmlReq reqToSend = (*backPressureHeader) + separator +
                          (*backPressure) + nullChar;

    delete backPressureHeader;
    delete backPressure;

    retval = sendMsg(reqToSend);
    if (-1 == retval) {
        fprintf (stderr, "Error in sendMsg while sending a backpressure."
                "apply message [0x%p] %s:%d\n", pthread_self(),
                __FILE__, __LINE__);
        //return(-1);
    }
#endif

}

void removeBackPressure()
{
    int32_t   retval;
    ///Form a back pressure message.
    std::string separator("\n\n");
    std::string nullChar;
    nullChar += '\0';

#if 0
    FSMXmlReq *backPressure = populateXmlBackPressure((unsigned char *)sessionId.c_str(),
                                                      false);

    FSMXmlReq *backPressureHeader = populateXmlHeaderMsg(
                                          BACK_PRESSURE_REMOVE_REQ,
                                          backPressure->getXmlMsgLength(),
                                          FORMAT_XML);

    FSMXmlReq reqToSend = (*backPressureHeader) + separator +
                          (*backPressure) + nullChar;

    delete backPressureHeader;
    delete backPressure;

    retval = sendMsg(reqToSend);
    if (-1 == retval) {
        fprintf (stderr, "Error in sendMsg while sending a backpressure."
                "remove message [0x%p] %s:%d\n", pthread_self(),
                __FILE__, __LINE__);
        //return(-1);
    }
#endif
}

void terminateProcess()
{

    ///Free the resouces here where interrupt is received. the fds that
    ///I can think of is listen Fds.
    if (listenFdIpv4 != INVALID_FD) {
        close(listenFdIpv4);
    }
    if (listenFdIpv6 != INVALID_FD) {
        close(listenFdIpv6);
    }

    fprintf (stderr, "Exiting since it was you who pressed interrupt!");
    exit(0);
}

int main(int argc, char **argv)
{
    int         option = 0;
    int         retval = 0;
    extern char *optarg;
    char        msgBuf[EP_HEADER_LEN];

    while((option = getopt(argc, argv, "p:r:C:A:V:P:F:M:m:D:d:h:")) != -1){
        switch(option)
        {
            case 'p':  ///Port
            {
                FpServerPort = atoi(optarg);
                break;
            }
            case 'r':  ///response (1|2)
            {
                Response = atoi(optarg);
                break;
            }
            case 'C': ///Supported ciphers.
            {
                ciphers = strdup(optarg);
                printf("Cipher is %s\n",ciphers);
                break;
            }
            case 'A': ///Authentication enabled(0|1)
            {
                sslAuthEnabled = atoi(optarg);
                break;
            }
            case 'V': ///Vserver ID
            {
                vsId = atoi(optarg);
                break;
            }
            case 'P': ///Policy Name
            {
                polName = strdup(optarg);
                break;
            }
            case 'F': ///File Name for Log collection.
            {
                filename = strdup(optarg);
                break;
            }
            case 'M': ///Policy Name
            {
                mode = atoi(optarg); /// 0 means Sync 1  means async.
                break;
            }
            case 'm': ///Mutual Authentication
            {
                isMutualAuth = atoi(optarg); ///1 means mutual authentication.
                break;
            }
            case 'D': ///Policy Name
            {
                delay = atoi(optarg); /// Delay for sending the response.
                break;
            }
            case 'd': ///SSL directory
            {
                dirname = strdup(optarg);
                break;
            }
            case 'h': ///Show help message
            {
                printf("\n [%s] -p <Port> -r <response(0|1)> -C <Cipher1:Cipher2...>"
                       "-A <SSL(0|1)> -P <policyName> -F <filename> -M <Sync/Async>"
                       "-m <mutualAuthentication> -D <Delay> -d <SSL directory path>\n",
                       argv[0]);
                exit(0);
            }
        }
    }

    if (NULL == filename) {
        printf("Must provide filename with -F option. Exiting...\n");
        exit(0);
    }

    registerSignalHandler();

    ///Open the file to write the log messages. The idea is to just redirect
    ///the stderr to a file.
    openLogfile();
    ///Test whether we really log the request.
    fprintf(stderr, "Log file is  %s\n", filename);

    fprintf(stderr, "[%s %d] Creating Notification Threads...\n", __FILE__, __LINE__);
    gFpsNotfObj.startNotfWorkerThreads();

    retval = acceptFSMConnection();

    if (-1 == retval) {
        fprintf (stderr, "acceptFsmConnection failed Exiting.[0x%p] %s:%d\n",
                pthread_self(), __FILE__,__LINE__);
        ///Close the connection rather than exiting.
        exit(1);
    }

    exit(0);
}

void openLogfile(void)
{
    int  logFd = -1;
    logFd = open(filename, O_RDWR|O_CREAT|O_APPEND);
    if (logFd < 0) {
        fprintf(stderr,"Failed to open the log file "
                "Check the Permission\n");
        exit(0);
    }
    ///Now dup stderr to newly opened descriptor.
    int retval = dup2(logFd, STDERR_FILENO);
    if (retval < 0) {
        fprintf(stderr, "Dupping of stderr failed.Exiting...\n");
        close(logFd);
        exit(0);
    }

    ///Look at the log and chk if I need to close STDERR_FILENO.
}
