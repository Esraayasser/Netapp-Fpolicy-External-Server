/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_schema.cc
 *
 * @author Sandeep Joshi
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 * @brief This file contains code parsing XML message received from
 *        NetApp storage appliance. It doesn't contain code for
 *        validation of messages though.
 */

#define LIBXML_SCHEMAS_ENABLED
#include <libxml/xmlschemastypes.h>
#include <libxml/xmlreader.h>
#include "fps_schemas.h"
#include <assert.h>
#include "fps_notification.h"
#include "fps_server.h"

class FSMConnection;
/* These hold the parsed schema definition for different types of response
 * received from fpolicy server.
 */

extern int32_t  Response;
extern int32_t  delay;
extern int32_t  mode;

static request_type getNotifyTypeEnumFromStr( const char *tagValue );
static fsm_request_type_e getReqTypeEnumFromStr( const char *tagValue );
static data_format_e getReqFormatEnumFromStr( const char *tagValue );
static alertSeverity_e getSevEnumFromString (const char *str );
static std::string  fileReqEnumToString(request_type enumVal);

Result_t FSMXmlRespHdr::getRespHdrFromXML( const char *respBuf )
{
    Result_t Result = RESULT_SUCCESS;
    xmlTextReaderPtr pXmlReader   = NULL;
    int              nodeType = 0;
    int              retVal = 0;

    pXmlReader = xmlReaderForMemory(respBuf, strlen(respBuf) , NULL, NULL, 0);

    while ((retVal = xmlTextReaderRead(pXmlReader)))
    {
        if ( -1 == retVal )
        {
            fprintf ( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
            goto Catch_Errors;
        }

        const char *tagName = NULL;
        const char *tagValue = NULL;

        nodeType = xmlTextReaderNodeType(pXmlReader);
        switch (nodeType)
        {
            /* Response info is contained in element tags */
            case XML_READER_TYPE_ELEMENT:
                tagName = (char *)xmlTextReaderConstName(pXmlReader);

                /* Ignore the element 'Header' as it does not contain any value, It contains
                 * other elements. */
                if ( strcmp(tagName, "Header") )
                {
                    /* Read the next element */
                    retVal = xmlTextReaderRead(pXmlReader);

                    /* Check if we are done with all the tags or some error occured */
                    if ( retVal <= 0 )
                    {
                        if ( -1 == retVal )
                        {
                            fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                        }
                        /* Reached the end of document */
                        goto Catch_Errors;
                    }

                    nodeType = xmlTextReaderNodeType(pXmlReader);
                    if ( nodeType == XML_READER_TYPE_TEXT )
                    {
                        tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
                        printf("%s:%s\n", tagName,tagValue);

                        /* Validate the elements */
                        if ( !strcmp(tagName, "NotfType") )
                        {
                            _reqType = getReqTypeEnumFromStr( tagValue );
                        }
                        else if ( !strcmp(tagName, "ContentLen") )
                        {
                            _payloadLen = (uint64_t) strtoull(tagValue,NULL,10);
                        }
                        else if ( !strcmp(tagName, "DataFormat") )
                        {
                            _format = getReqFormatEnumFromStr( tagValue );
                        }
                        else
                        {
                            /* As schema is validated, we should not have any other element */
                            assert(0);
                        }
                    }
                    else
                    {
                       fprintf (stderr,"ERROR: Element %s not followed by value", tagName);
                       Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                       goto Catch_Errors;
                    }
                }

                break;

            default:
                break;
        }
    }

Catch_Errors:
    xmlFreeTextReader(pXmlReader);
    return Result;
}

Result_t FSMXmlHandShakeResp::getHandshakeRespPayloadFromXML( const char *respBuf  )
{
    Result_t Result = RESULT_SUCCESS;
    xmlTextReaderPtr pXmlReader   = NULL;
    int              nodeType = 0;
    int              retVal = 0;

    pXmlReader = xmlReaderForMemory(respBuf, strlen(respBuf) , NULL, NULL, 0);

    while ((retVal = xmlTextReaderRead(pXmlReader)))
    {
        if ( -1 == retVal )
        {
            fprintf ( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
            goto Catch_Errors;
        }

        const char *tagName = NULL;
        const char *tagValue = NULL;

        nodeType = xmlTextReaderNodeType(pXmlReader);
        switch (nodeType)
        {
            /* Response info is contained in element tags */
            case XML_READER_TYPE_ELEMENT:
                tagName = (char *)xmlTextReaderConstName(pXmlReader);


				/* Validate the elements */
                //if ( !strcmp(tagName,"_VsUUID") )
                if ( !strcmp(tagName,"VsUUID") )
                {
						/* Read the next element */
                        retVal = xmlTextReaderRead(pXmlReader);

                        /* Check if we are donewth all the tags or some error occured */
                        if ( retVal <= 0 )
                        {
                            if ( -1 == retVal )
                            {
                                fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                            }
                            /* Reached the end of document */
                            goto Catch_Errors;
                        }

						nodeType = xmlTextReaderNodeType(pXmlReader);
						if ( nodeType == XML_READER_TYPE_TEXT )
						{
                            tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
                            printf("%s:%s\n", tagName,tagValue);
                            strncpy( _VsUUID, tagValue, MAX_SESSION_ID_LEN);
                            fprintf (stderr,"_VsUUID %s\n", _VsUUID);
                                //_VsUUID
                                //tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
                                //printf("%s:%s\n", tagName,tagValue);
                                //_vserverId = atoi( tagValue );
                                //fprintf (stderr,"_vserverId %d\n", _vserverId);
						}
				}
				else if ( !strcmp(tagName,"PolicyName") )
				{
						/* Read the next element */
                        retVal = xmlTextReaderRead(pXmlReader);

                        /* Check if we are done with all the tags or some error occured */
                        if ( retVal <= 0 )
                        {
                            if ( -1 == retVal )
                            {
                                fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                            }
                            /* Reached the end of document */
                            goto Catch_Errors;
                        }

						nodeType = xmlTextReaderNodeType(pXmlReader);
						if ( nodeType == XML_READER_TYPE_TEXT )
						{
								tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
								printf("%s:%s\n", tagName,tagValue);
                                strncpy( _policyName, tagValue, MAX_POLICY_NAME_LEN);
								fprintf (stderr,"PolicyName %s\n", _policyName);
						}
				}
				else if ( !strcmp(tagName,"SessionId") )
				{
						/* Read the next element */
                        retVal = xmlTextReaderRead(pXmlReader);

                        /* Check if we are done with all the tags or some error occured */
                        if ( retVal <= 0 )
                        {
                            if ( -1 == retVal )
                            {
                                fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                            }
                            /* Reached the end of document */
                            goto Catch_Errors;
                        }

						nodeType = xmlTextReaderNodeType(pXmlReader);
						if ( nodeType == XML_READER_TYPE_TEXT )
						{
								tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
								printf("%s:%s\n", tagName,tagValue);
								strncpy( _sessionId, tagValue, MAX_SESSION_ID_LEN );
								fprintf (stderr,"SessionId %s\n", _sessionId);
						}
				}
				else if ( !strcmp(tagName,"ProtVersion") )
				{
						/* Read the next element */
                        retVal = xmlTextReaderRead(pXmlReader);

                        /* Check if we are done with all the tags or some error occured */
                        if ( retVal <= 0 )
                        {
                            if ( -1 == retVal )
                            {
                                fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                            }
                            /* Reached the end of document */
                            goto Catch_Errors;
                        }

						nodeType = xmlTextReaderNodeType(pXmlReader);
						if ( nodeType == XML_READER_TYPE_TEXT )
						{
								tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
								printf("%s:%s\n", tagName,tagValue);
								_protocolVersion = tagValue;
								fprintf (stderr,"ProtVersion %s\n", _protocolVersion.c_str());
						}
				}
				else
				{
						/* As schema is validated, we should not have any other element */
						//assert(0);
				}

                break;

            default:
                break;
        }
    }

Catch_Errors:
    xmlFreeTextReader(pXmlReader);
    return Result;
}

Result_t FSMXmlNotfResp::getNotfyRespPayloadFromXML( const char *respBuf  )
{
    Result_t Result = RESULT_SUCCESS;
    xmlTextReaderPtr pXmlReader   = NULL;
    int              nodeType = 0;
    int              retVal = 0;

    pXmlReader = xmlReaderForMemory(respBuf, strlen(respBuf) , NULL, NULL, 0);

    while ((retVal = xmlTextReaderRead(pXmlReader)))
    {
        if ( -1 == retVal )
        {
            fprintf ( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
            goto Catch_Errors;
        }

        const char *tagName = NULL;
        const char *tagValue = NULL;

        nodeType = xmlTextReaderNodeType(pXmlReader);
        switch (nodeType)
        {
            /* Response info is contained in element tags */
            case XML_READER_TYPE_ELEMENT:
                tagName = (char *)xmlTextReaderConstName(pXmlReader);

                if ( !strcmp(tagName,"ReqId") )
                {
                    /* Read the next element */
                    retVal = xmlTextReaderRead(pXmlReader);

                    /* Check if we are done with all the tags or some error occured */
                    if ( retVal <= 0 )
                    {
                        if ( -1 == retVal )
                        {
                            fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                        }
                        /* Reached the end of document */
                        goto Catch_Errors;
                    }

                    nodeType = xmlTextReaderNodeType(pXmlReader);
                    if ( nodeType == XML_READER_TYPE_TEXT )
                    {
                        tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
                        printf("%s:%s\n", tagName,tagValue);

                        _reqId = (uint64_t) strtoull(tagValue,NULL,10);
                        fprintf (stderr,"ReqId %llu\n", (unsigned long long)_reqId );
                    }
                }
                else if ( !strcmp(tagName,"ReqType") )
                {
                    /* Read the next element */
                    retVal = xmlTextReaderRead(pXmlReader);

                    /* Check if we are done with all the tags or some error occured */
                    if ( retVal <= 0 )
                    {
                        if ( -1 == retVal )
                        {
                            fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                        }
                        /* Reached the end of document */
                        goto Catch_Errors;
                    }

                    nodeType = xmlTextReaderNodeType(pXmlReader);
                    if ( nodeType == XML_READER_TYPE_TEXT )
                    {
                        tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
                        printf("%s:%s\n", tagName,tagValue);

                        _notifyType = getNotifyTypeEnumFromStr( tagValue );
                        fprintf (stderr,"ReqType %d\n", _notifyType);
                    }
                }
                else if ( !strcmp(tagName,"NotfResp") )
                {
                    //_respCode = (FSMResponseCode) atoi(tagValue);
                    //fprintf (stderr,"NotfResp %d\n", _respCode);
                }
                else
                {
                    /* IGNORE */
                }
                break;

            default:
                break;
        }
    }

Catch_Errors:
    xmlFreeTextReader(pXmlReader);
    //xmlCleanupParser();
    return Result;
}

Result_t FSMXmlStatusResp::getStatusRespPayloadFromXML( const char *respBuf  )
{
    Result_t Result = RESULT_SUCCESS;
    xmlTextReaderPtr pXmlReader   = NULL;
    int              nodeType = 0;
    int              retVal = 0;

    pXmlReader = xmlReaderForMemory(respBuf, strlen(respBuf) , NULL, NULL, 0);

    while ((retVal = xmlTextReaderRead(pXmlReader)))
    {
        if ( -1 == retVal )
        {
            fprintf ( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
            goto Catch_Errors;
        }

        const char *tagName = NULL;
        const char *tagValue = NULL;

        nodeType = xmlTextReaderNodeType(pXmlReader);
        switch (nodeType)
        {
            /* Response info is contained in element tags */
            case XML_READER_TYPE_ELEMENT:
					tagName = (char *)xmlTextReaderConstName(pXmlReader);

					if ( !strcmp(tagName,"ReqId") )
					{
					        /* Read the next element */
                            retVal = xmlTextReaderRead(pXmlReader);

                            /* Check if we are done with all the tags or some error occured */
                            if ( retVal <= 0 )
                            {
                                if ( -1 == retVal )
                                {
                                    fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                    Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                                }
                                /* Reached the end of document */
                                goto Catch_Errors;
                            }

							nodeType = xmlTextReaderNodeType(pXmlReader);
							if ( nodeType == XML_READER_TYPE_TEXT )
							{
									tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
									printf("%s:%s\n", tagName,tagValue);
									_reqId = (uint64_t) strtoull(tagValue,NULL,10);
									fprintf (stderr,"ReqId %llu\n", (unsigned long long)_reqId );
							}
					}
					else if ( !strcmp(tagName,"ReqType") )
					{
							/* Read the next element */
                            retVal = xmlTextReaderRead(pXmlReader);

                            /* Check if we are done with all the tags or some error occured */
                            if ( retVal <= 0 )
                            {
                                if ( -1 == retVal )
                                {
                                    fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                    Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                                }
                                /* Reached the end of document */
                                goto Catch_Errors;
                            }

							nodeType = xmlTextReaderNodeType(pXmlReader);
							if ( nodeType == XML_READER_TYPE_TEXT )
							{
									tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
									printf("%s:%s\n", tagName,tagValue);
									_reqType = getNotifyTypeEnumFromStr( tagValue );
									fprintf (stderr,"ReqType %d\n", _reqType);
							}
					}
					else
					{
							/* As schema is validated, we should not have any other element */
							//assert(0);
					}
					break;

            default:
                break;
        }
    }

Catch_Errors:
    xmlFreeTextReader(pXmlReader);
    return Result;
}

Result_t FSMXmlAlerts::getAlertPayloadFromXML( const char *respBuf  )
{
    Result_t Result = RESULT_SUCCESS;
    xmlTextReaderPtr pXmlReader   = NULL;
    int              nodeType = 0;
    int              retVal = 0;

    pXmlReader = xmlReaderForMemory(respBuf, strlen(respBuf) , NULL, NULL, 0);

    while ((retVal = xmlTextReaderRead(pXmlReader)))
    {
        if ( -1 == retVal )
        {
            fprintf ( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
            Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
            goto Catch_Errors;
        }

        const char *tagName = NULL;
        const char *tagValue = NULL;

		nodeType = xmlTextReaderNodeType(pXmlReader);
		switch (nodeType)
		{
				/* Response info is contained in element tags */
				case XML_READER_TYPE_ELEMENT:
						tagName = (char *)xmlTextReaderConstName(pXmlReader);

						if ( !strcmp(tagName,"SessionId") )
						{
								/* Read the next element */
                                retVal = xmlTextReaderRead(pXmlReader);

                                /* Check if we are done with all the tags or some error occured */
                                if ( retVal <= 0 )
                                {
                                    if ( -1 == retVal )
                                    {
                                        fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                        Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                                    }
                                    /* Reached the end of document */
                                    goto Catch_Errors;
                                }

								nodeType = xmlTextReaderNodeType(pXmlReader);
								if ( nodeType == XML_READER_TYPE_TEXT )
								{
										tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
										printf("%s:%s\n", tagName,tagValue);

										strncpy( _sessionId, tagValue, MAX_SESSION_ID_LEN );
										fprintf (stderr,"SessionId %s\n", _sessionId);
								}
						}
						if ( !strcmp(tagName,"Severity") )
						{
								/* Read the next element */
                                /* Read the next element */
                                retVal = xmlTextReaderRead(pXmlReader);

                                /* Check if we are done with all the tags or some error occured */
                                if ( retVal <= 0 )
                                {
                                    if ( -1 == retVal )
                                    {
                                        fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                        Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                                    }
                                    /* Reached the end of document */
                                    goto Catch_Errors;
                                }

								nodeType = xmlTextReaderNodeType(pXmlReader);
								if ( nodeType == XML_READER_TYPE_TEXT )
								{
										tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
										printf("%s:%s\n", tagName,tagValue);

										_alertSeverity = getSevEnumFromString(tagValue);
										fprintf (stderr,"Severity %d\n", _alertSeverity );
								}
						}
						if ( !strcmp(tagName,"AlertMsg") )
						{
                                /* Read the next element */
                                retVal = xmlTextReaderRead(pXmlReader);

                                /* Check if we are done with all the tags or some error occured */
                                if ( retVal <= 0 )
                                {
                                    if ( -1 == retVal )
                                    {
                                        fprintf( stderr ,"ERROR: xmlTextReaderRead Failed.. \n");
                                        Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
                                    }
                                    /* Reached the end of document */
                                    goto Catch_Errors;
                                }

								nodeType = xmlTextReaderNodeType(pXmlReader);
								if ( nodeType == XML_READER_TYPE_TEXT )
								{
										tagValue = (char *)xmlTextReaderConstValue(pXmlReader);
										printf("%s:%s\n", tagName,tagValue);

										strncpy( _alertStr, tagValue, MAX_ALERT_STR_LEN);
										fprintf (stderr,"AlertMsg %s\n",_alertStr );
								}
						}
						else
						{
								/* As schema is validated, we should not have any other element */
								//assert(0);
						}
						break;

            default:
                break;
        }
    }

Catch_Errors:
    xmlFreeTextReader(pXmlReader);
    return Result;
}

static request_type getNotifyTypeEnumFromStr( const char *tagValue )
{
    request_type  notfType = FPOLICY_REQUEST_NULL;

    if ( !strcmp(tagValue,"SMB_OPEN") )
    {
        notfType = SMB_OPEN;
    }
    else if ( !strcmp(tagValue,"SMB_CLOSE") )
    {
        notfType = SMB_CLOSE;
    }
    else if ( !strcmp(tagValue,"SMB_CREAT") )
    {
        notfType = SMB_CREAT;
    }
    else if ( !strcmp(tagValue,"SMB_CREAT_DIR") )
    {
        notfType = SMB_CREAT_DIR;
    }
    else if ( !strcmp(tagValue,"SMB_DEL") )
    {
        notfType = SMB_DEL;
    }
    else if ( !strcmp(tagValue,"SMB_DEL_DIR") )
    {
        notfType = SMB_DEL_DIR;
    }
    else if ( !strcmp(tagValue,"SMB_REN") )
    {
        notfType = SMB_REN;
    }
    else if ( !strcmp(tagValue,"SMB_REN_DIR") )
    {
        notfType = SMB_REN_DIR;
    }
    else if ( !strcmp(tagValue,"SMB_GET_ATTR") )
    {
        notfType = SMB_GET_ATTR;
    }
    else if ( !strcmp(tagValue,"SMB_SET_ATTR") )
    {
        notfType = SMB_SET_ATTR;
    }
    else if ( !strcmp(tagValue,"SMB_LNK") )
    {
        notfType = SMB_LNK;
    }
    else if ( !strcmp(tagValue,"SMB_SYM_LNK") )
    {
        notfType = SMB_SYM_LNK;
    }
    else if ( !strcmp(tagValue,"SMB_RD") )
    {
        notfType = SMB_RD;
    }
    else if ( !strcmp(tagValue,"SMB_WR") )
    {
        notfType = SMB_WR;
    }
    else if ( !strcmp(tagValue,"NFS_LOOKUP") )
    {
        notfType = NFS_LOOKUP;
    }
    else if ( !strcmp(tagValue,"NFS_CREAT") )
    {
        notfType = NFS_CREAT;
    }
    else if ( !strcmp(tagValue,"NFS_CREAT_DIR") )
    {
        notfType = NFS_CREAT_DIR;
    }
    else if ( !strcmp(tagValue,"NFS_DEL") )
    {
        notfType = NFS_DEL;
    }
    else if ( !strcmp(tagValue,"NFS_DEL_DIR") )
    {
        notfType = NFS_DEL_DIR;
    }
    else if ( !strcmp(tagValue,"NFS_REN") )
    {
        notfType = NFS_REN;
    }
    else if ( !strcmp(tagValue,"NFS_REN_DIR") )
    {
        notfType = NFS_REN_DIR;
    }
    else if ( !strcmp(tagValue,"NFS_OPEN") )
    {
        notfType = NFS_OPEN;
    }
    else if ( !strcmp(tagValue,"NFS_CLOSE") )
    {
        notfType = NFS_CLOSE;
    }
    else if ( !strcmp(tagValue,"NFS_RD") )
    {
        notfType = NFS_RD;
    }
    else if ( !strcmp(tagValue,"NFS_WR") )
    {
        notfType = NFS_WR;
    }
    else if ( !strcmp(tagValue,"NFS_GET_ATTR") )
    {
        notfType = NFS_GET_ATTR;
    }
    else if ( !strcmp(tagValue,"NFS_SET_ATTR") )
    {
        notfType = NFS_SET_ATTR;
    }
    else if ( !strcmp(tagValue,"NFS_LNK") )
    {
        notfType = NFS_LNK;
    }
    else if ( !strcmp(tagValue,"NFS_SYM_LNK") )
    {
        notfType = NFS_SYM_LNK;
    }
    else
    {
    }

    return notfType;
}

static fsm_request_type_e getReqTypeEnumFromStr( const char *tagValue )
{
    fsm_request_type_e  reqType = FSM_REQ_TYPE_INVALID;

    if ( !strcmp(tagValue,"NEGO_REQ") )
    {
        reqType = NEGO_MSG_REQ;
    }
    else if ( !strcmp(tagValue,"NEGO_RESP") )
    {
        reqType = NEGO_MSG_RESP;
    }
    else if ( !strcmp(tagValue,"SCREEN_REQ") )
    {
        reqType = FILE_NOTIFY_REQ;
    }
    else if ( !strcmp(tagValue,"SCREEN_RESP") )
    {
        reqType = FILE_NOTIFY_RESP;
    }
    else if ( !strcmp(tagValue,"VOL_NOTFICATION") )
    {
        reqType = VOL_NOTIFY;
    }
    else if ( !strcmp(tagValue,"SCREEN_CANCEL") )
    {
        reqType = FILE_NOTIFY_CANCEL_REQ;
    }
    else if ( !strcmp(tagValue,"STATUS_QUERY_REQ") )
    {
        reqType = STATUS_QUERY_REQ;
    }
    else if ( !strcmp(tagValue,"STATUS_QUERY_RESP") )
    {
        reqType = STATUS_QUERY_RESP;
    }
    else if ( !strcmp(tagValue,"BACK_PRESSURE_APPLY") )
    {
        reqType = BACKBACK_RESSURE_APPLY_REQ;
    }
    else if ( !strcmp(tagValue,"BACK_PRESSURE_REM") )
    {
        reqType = BACK_PRESSURE_REMOVE_REQ;
    }
    if ( !strcmp(tagValue,"KEEP_ALIVE") )
    {
        reqType = KEEP_ALIVE_REQ;
    }
    else if ( !strcmp(tagValue,"ALERT_MSG") )
    {
        reqType = ALERTS;
    }
    else
    {
       //assert(0);
    }

    return reqType;
}


static data_format_e getReqFormatEnumFromStr( const char *tagValue )
{
    data_format_e  reqFormat = FORMAT_UNKNOWN;

    if ( !strcmp(tagValue,"XML") )
    {
        reqFormat = FORMAT_XML;
    }
    else
    {
        /* Currently supporting only XML */
    }

    return reqFormat;
}

alertSeverity_e getSevEnumFromString (const char *tagValue )
{
    alertSeverity_e sev = ALERT_SEVERITY_NONE;

    if ( !strcmp(tagValue,"FATAL") )
    {
        sev = ALERT_SEVERITY_FATAL;
    }
    else if ( !strcmp(tagValue,"WARNING") )
    {
        sev = ALERT_SEVERITY_WARNING;
    }
    else
    {
    }

    return sev;
}

FSMXmlRespHdr::FSMXmlRespHdr()
{
    _reqType = FSM_REQ_TYPE_INVALID;
    _payloadLen = 0;
    _format = FORMAT_UNKNOWN;

}

FSMXmlHandShakeResp::FSMXmlHandShakeResp()
{
    _vserverId = 0;
    memset(_sessionId,'\0',MAX_SESSION_ID_LEN+1);
    memset(_policyName,'\0',MAX_POLICY_NAME_LEN+1);
}

FSMXmlNotfResp::FSMXmlNotfResp()
{
    _reqId = 0;
    _notifyType = FPOLICY_REQUEST_NULL;
    //_respCode = FPOLICY_RESPONSE_CODE_MIN;
}

FSMXmlStatusResp::FSMXmlStatusResp()
{
    _reqId = 0;
    _reqType = FPOLICY_REQUEST_NULL;
    _respStatusCode = REQ_STATUS_INVALID;
}

FSMXmlAlerts::FSMXmlAlerts()
{
    memset(_sessionId,'\0',MAX_SESSION_ID_LEN+1);
    _alertSeverity = ALERT_SEVERITY_NONE;
    memset( _alertStr,  '\0', MAX_ALERT_STR_LEN + 1 );
}

int32_t
FSMConnection::processFSMRequest( unsigned char *respData, int32_t len )
{
    Result_t Result = RESULT_SUCCESS;
    FSMXmlRespHdr respHdr;

    char *respXmlBuf = new char [ len+1 ];

    memcpy(respXmlBuf,respData,len);
    respXmlBuf[len] = '\0';

    char *pSavePtr = NULL;

    /* Get response header and validate the fields */
    char *pBuf = strtok_r(respXmlBuf,"\n", &pSavePtr);
    if ( NULL == pBuf )
    {
        fprintf (stderr, "RESP HEADER is NULL. [0x%p] %s:%d\n",
               pthread_self(),__FILE__,__LINE__);

		Result = RESULT_ERROR_GENERAL_FAILURE;
		goto Catch_Errors;

    }

    fprintf (stderr, "RESP HDR:\n%s\n. [0x%p] %s:%d\n",
            pBuf,pthread_self(),__FILE__,__LINE__);


    if ( 0 !=  respHdr.getRespHdrFromXML(pBuf) )
    {
        fprintf (stderr, "RESP HDR:getRespHdrFromXML Failed\n. [0x%p] %s:%d\n",
               pthread_self(),__FILE__,__LINE__);
		Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
        goto Catch_Errors;
    }

    /* Ignore the keepalive requests */
    if ( KEEP_ALIVE_REQ == respHdr.getReqType() )
    {
        goto Catch_Errors;
    }

    /* Get response payload and validate the fields */
    pBuf = strtok_r(NULL,"\n",&pSavePtr);
	if ( NULL == pBuf )
	{
        fprintf (stderr, "RESP BUFFER is NULL. [0x%p] %s:%d\n",
               pthread_self(),__FILE__,__LINE__);
		Result = RESULT_ERROR_GENERAL_FAILURE;
        goto Catch_Errors;
	}

    switch ( respHdr.getReqType() )
    {
        case FILE_NOTIFY_REQ:
        {
            fprintf (stderr, "\n\nRCVD:: SCREEN REQ from FSM.\n\n"
            "[0x%p] %s:%d \n",
            pthread_self(),__FILE__,__LINE__ );

            FSMXmlNotfResp respScreenXml;
            fprintf (stderr, "NOTIFY PAYLOAD:\n%s\n. [0x%p] %s:%d\n",
                    pBuf,pthread_self(),__FILE__,__LINE__);
            ///Form a response to FPolicy Server. As of now we just send
            ///allow or deny.
            if (mode == 0) {
                if ( 0 != respScreenXml.getNotfyRespPayloadFromXML(pBuf) )
                {
                    fprintf (stderr, "getNotfyRespPayloadFromXML Failed\n. [0x%p] %s:%d\n",
                            pthread_self(),__FILE__,__LINE__);
				    Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
				    goto Catch_Errors;
                }
                FSMXmlReq *FpsResponse = populateXmlNotificationResp(respScreenXml.getReqId(),
                                         (unsigned char*)fileReqEnumToString(respScreenXml.getNotifyType()).c_str(),
                                         Response);

                ///Form a message header now
                FSMXmlReq *FpsMsgHeader = populateXmlHeaderMsg(FILE_NOTIFY_RESP,
                                           FpsResponse->getXmlMsgLength(),
                                           FORMAT_XML);
                std::string   nullString;
                nullString += '\0'; ///< Add a null character to nullString.

                std::string separator("\n\n");
                FSMXmlReq reqToSend = (*FpsMsgHeader) + separator + (*FpsResponse) + nullString;

                delete FpsResponse;
                delete FpsMsgHeader;

                sleep( delay );

                int32_t retval = sendMsg(reqToSend);
                if (-1 == retval) {
                    fprintf (stderr, "Error in sendMsg while sending a response."
                            "return with error [0x%p] %s:%d\n", pthread_self(),
                            __FILE__, __LINE__);
                    delete [] respXmlBuf;
                    return(-1);
                }
                fprintf (stderr, "\n\nSENT:: SCREEN to FSM.\n\n"
                                                        "[0x%p] %s:%d \n",
                                                        pthread_self(),__FILE__,__LINE__ );
            }
        }
        break;

        case STATUS_QUERY_REQ:
        {
            fprintf (stderr, "\n\nRCVD:: STATUS_QUERY_REQ from FSM.\n\n"
            "[0x%p] %s:%d \n",
            pthread_self(),__FILE__,__LINE__ );

			FSMXmlStatusResp respStatusXml;
            fprintf (stderr, "STATUS PAYLOAD:\n%s\n. [0x%p] %s:%d\n",
                    pBuf,pthread_self(),__FILE__,__LINE__);

            if ( 0 != respStatusXml.getStatusRespPayloadFromXML(pBuf) )
            {
                fprintf (stderr, "getStatusRespPayloadFromXML Failed\n. [0x%p] %s:%d\n",
                        pthread_self(),__FILE__,__LINE__);
				Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
				goto Catch_Errors;
            }

            if (mode == 0) {
                FSMXmlReq *statusResp = populateStatusResponse( respStatusXml.getReqId(),
                                (unsigned char*)fileReqEnumToString(respStatusXml.getReqType()).c_str(),1);

                ///Form a message header now
                FSMXmlReq *FpsMsgHeader = populateXmlHeaderMsg(STATUS_QUERY_RESP,
                        statusResp->getXmlMsgLength(),
                        FORMAT_XML);
                std::string   nullString;
                nullString += '\0'; ///< Add a null character to nullString.
                std::string separator("\n\n");
                FSMXmlReq reqToSend = (*FpsMsgHeader) + separator + (*statusResp) + nullString;

                delete FpsMsgHeader;
                delete statusResp;

                int32_t retval = sendMsg(reqToSend);
                if (-1 == retval) {
                    fprintf (stderr, "Error in sendMsg while sending a response."
                            "return with error [0x%p] %s:%d\n", pthread_self(),
                            __FILE__, __LINE__);
                            delete [] respXmlBuf;
                    return(-1);
                }
                fprintf (stderr, "\n\nSENT:: STATUS_RESP to FSM.\n\n"
                                                        "[0x%p] %s:%d \n",
                                                        pthread_self(),__FILE__,__LINE__ );
            }
        }
        break;

        case VOL_NOTIFY :
        {
            fprintf (stderr, "\n\nRCVD:: ALERT from FSM.\n\n"
            "[0x%p] %s:%d \n",
            pthread_self(),__FILE__,__LINE__ );

            fprintf (stderr, "ALERT PAYLOAD:\n%s\n. [0x%p] %s:%d\n",
                    pBuf,pthread_self(),__FILE__,__LINE__);
        }
        break;

        case ALERTS:
        {
            fprintf (stderr, "\n\nRCVD:: ALERT from FSM.\n\n"
            "[0x%p] %s:%d \n",
            pthread_self(),__FILE__,__LINE__ );

			FSMXmlAlerts reqAlert;
            fprintf (stderr, "ALERT PAYLOAD:\n%s\n. [0x%p] %s:%d\n",
                    pBuf,pthread_self(),__FILE__,__LINE__);

            if ( 0 != reqAlert.getAlertPayloadFromXML( pBuf ) )
            {
                fprintf (stderr, "getAlertPayloadFromXML Failed\n. [0x%p] %s:%d\n",
                        pthread_self(),__FILE__,__LINE__);
				Result = RESULT_ERROR_FPOLICY_CONN_PARSE_NOTIFICATION;
				goto Catch_Errors;
            }
        }
        break;

        default:
         break;
    }

Catch_Errors:
    delete [] respXmlBuf;

	if ( 0 != Result )
	{
        return -1;
	}
	else
	{
        return 0;
	}

}


static std::string  fileReqEnumToString(request_type enumVal)
{
    std::string fileReqType;

    switch(enumVal) {
        case SMB_OPEN :
        {
            fileReqType = "SMB_OPEN";
            break;
        }
        case SMB_CLOSE :
        {
            fileReqType = "SMB_CLOSE";
            break;
        }
        case SMB_CREAT :
        {
            fileReqType = "SMB_CREAT";
            break;
        }
        case SMB_CREAT_DIR :
        {
            fileReqType = "SMB_CREAT_DIR";
            break;
        }
        case SMB_DEL :
        {
            fileReqType = "SMB_DEL";
            break;
        }
        case SMB_DEL_DIR :
        {
            fileReqType = "SMB_DEL_DIR";
            break;
        }
        case SMB_REN :
        {
            fileReqType = "SMB_REN";
            break;
        }
        case SMB_REN_DIR :
        {
            fileReqType = "SMB_REN_DIR";
            break;
        }
        case SMB_GET_ATTR :
        {
            fileReqType = "SMB_GET_ATTR";
            break;
        }
        case SMB_SET_ATTR :
        {
            fileReqType = "SMB_SET_ATTR";
            break;
        }
        case SMB_LNK :
        {
            fileReqType = "SMB_LNK";
            break;
        }
        case SMB_SYM_LNK :
        {
            fileReqType = "SMB_SYM_LNK";
            break;
        }
        case SMB_RD :
        {
            fileReqType = "SMB_RD";
            break;
        }
        case SMB_WR :
        {
            fileReqType = "SMB_WR";
            break;
        }
        case NFS_LOOKUP :
        {
            fileReqType = "NFS_LOOKUP";
            break;
        }
        case NFS_CREAT :
        {
            fileReqType = "NFS_CREAT";
            break;
        }
        case NFS_CREAT_DIR :
        {
            fileReqType = "NFS_CREAT_DIR";
            break;
	}
        case NFS_DEL :
        {
            fileReqType = "NFS_DEL";
            break;
        }
        case NFS_DEL_DIR :
        {
            fileReqType = "NFS_DEL_DIR";
            break;
        }
        case NFS_REN :
        {
            fileReqType = "NFS_REN";
            break;
        }
        case NFS_REN_DIR :
        {
            fileReqType = "NFS_REN_DIR";
            break;
        }
        case NFS_OPEN :
        {
            fileReqType = "NFS_OPEN";
            break;
        }
        case NFS_CLOSE :
        {
            fileReqType = "NFS_CLOSE";
            break;
        }
        case NFS_RD :
        {
            fileReqType = "NFS_RD";
            break;
        }
        case NFS_WR :
        {
            fileReqType = "NFS_WR";
            break;
        }
        case NFS_GET_ATTR :
        {
            fileReqType = "NFS_GET_ATTR";
            break;
        }
        case NFS_SET_ATTR :
        {
            fileReqType = "NFS_SET_ATTR";
            break;
        }
        case NFS_LNK :
        {
            fileReqType = "NFS_LNK";
            break;
        }
        case NFS_SYM_LNK :
        {
            fileReqType = "NFS_SYM_LNK";
            break;
        }
        /* case VOL_NOTF :
        {
            fileReqType = "VOL_NOTF";
            break;
        } */
        default :
        {
            fileReqType = "UNKNOWN";
            break;
        }
    }

    return fileReqType;
}

