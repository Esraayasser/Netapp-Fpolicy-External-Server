/**
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fsm_schemas.h
 *
 * @author Sandeep Joshi
 *
 * @date 12-31-2011
 *
 * Languages Used : C & C++
 *
 * @brief This file contains classes and structures for
 *        formation of file screen notification and status
 *        notfication in XML format.
 *
 */


#ifndef _FP_SCHEMAS_H
#define _FP_SCHEMAS_H

#include <iostream>
#include <string>
#include "fps_types.h"
#include "fps_notification.h"

#define MAX_ALERT_MSG_LEN      256
#define MAX_POLICY_NAME_LEN   256

class FSMXmlRespHdr
{
protected:
    fsm_request_type_e  _reqType;
    uint32_t            _payloadLen;
    data_format_e       _format;

public:
   FSMXmlRespHdr ();
   ~FSMXmlRespHdr () { };

    fsm_request_type_e getReqType()     { return _reqType; }
    uint32_t           getpayloadLen()  { return _payloadLen; }
    data_format_e      getDataFormat()  { return _format; }

    Result_t getRespHdrFromXML( const char *respBuf );
};

class FSMXmlHandShakeResp
{
private:
    uint32_t                      _vserverId;
    char                          _VsUUID[MAX_SESSION_ID_LEN + 1];
    char                          _sessionId[MAX_SESSION_ID_LEN + 1];
    char                          _policyName[MAX_POLICY_NAME_LEN + 1];
    std::string                   _protocolVersion;

public:
    FSMXmlHandShakeResp ();
    ~FSMXmlHandShakeResp() { }
    uint32_t getVserverId(void) {return _vserverId;}
    std::string getVserverUUID(void) { return std::string(_VsUUID);}
    std::string getSessionId(void) { return std::string(_sessionId);}
    std::string getPolicyName(void) { return std::string(_policyName);}
    std::string getProtocolVersion(void) { return _protocolVersion;}


    Result_t getHandshakeRespPayloadFromXML( const char *respBuf  );
};

class FSMXmlNotfResp
{
private:
    uint64_t        _reqId;              //req ID for which the response is received
    request_type    _notifyType;         //req type

public:
    FSMXmlNotfResp ();
    ~FSMXmlNotfResp() { }

    uint64_t getReqId ()             { return _reqId; }
    request_type getNotifyType ()    { return _notifyType; }

    Result_t getNotfyRespPayloadFromXML( const char *respBuf  );
};

class FSMXmlStatusResp
{
private:
    uint64_t        _reqId;           //req ID for which the response is received
    request_type    _reqType;         //req type
    reqStatusCode_e _respStatusCode;  //response e.g WORKING/REJECT

public:
    FSMXmlStatusResp ();
    ~FSMXmlStatusResp() { }

    uint64_t getReqId ()                { return _reqId; }
    request_type getReqType ()          { return _reqType; }
    reqStatusCode_e getRespStatusCode (){ return _respStatusCode; }

    Result_t getStatusRespPayloadFromXML( const char *respBuf  );
};

class FSMXmlAlerts
{
private:
    char            _sessionId[FP_MAX_UUID_LEN + 1];
    alertSeverity_e _alertSeverity;
    char            _alertStr[MAX_ALERT_STR_LEN + 1];

public:
    FSMXmlAlerts ();
    ~FSMXmlAlerts () { }

    uint64_t getAlertSeverity ()     { return _alertSeverity; }
    char*    getSessionId ()         { return _sessionId; }
    char*    getAlertStr()           { return _alertStr; }

    Result_t getAlertPayloadFromXML( const char *respBuf  );
};

#endif
