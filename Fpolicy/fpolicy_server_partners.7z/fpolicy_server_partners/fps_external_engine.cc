/*
 * Copyright (C) 2012 by NetApp, Inc.  All Rights Reserved.
 *
 * @file fps_external_engine.cc
 *
 * @author Sudip Kumar Panda
 *
 * @date 01-25-2012
 *
 * Languages Used : C & C++
 *
 * @brief This file contains code for connection mgmt. This include
 *        establishing the connection(over SSL and TCP) and communication
 *        with external NetApp storage appliance.
 */

#include "fps_external_engine.h"
#include "fps_notification.h"
#include "fps_server.h"
#include <uuid.h>
#include <pthread.h>
#include "fps_schemas.h"

//======================
//Global Variables.
//=======================
static BIO             *bio_err      = NULL; ///< BIO error
static pthread_mutex_t *sslLocks     = NULL; ///< SSL MT-Safe.
int32_t                FpServerPort  = 4433;
int32_t                Response = 1;
int32_t                mode = 0;
int32_t                isMutualAuth = 1; ///By default mutual authentication is true.
char                   *ciphers = NULL;
int32_t                sslAuthEnabled = 1;
int32_t                sslHandshakeTimeout = 5;
int32_t                fpsHandshakeTimeout = 5;
std::string            sessionId;
extern int32_t         vsId;
extern char *          polName;
extern char *          dirname;
int32_t                delay = 0;
int                    listenFdIpv4 = INVALID_FD;
int                    listenFdIpv6 = INVALID_FD;


static int32_t sslSendMsg(SSL  *ssl, const unsigned char *msgBuf,
                          int32_t msgLength, uint32_t timeout);
static int32_t sslRecvMsg(SSL *ssl, unsigned char *msgBuf,
                          int32_t msgLength, uint32_t timeout);

static int32_t chkMsgLengthFormat(const unsigned char *lengthHeader,
                                  int32_t *payloadLength);

static int32_t readMsg(int32_t fd , unsigned char *msgBuf,
                       int32_t msgLength, uint32_t timeout);

static int32_t writeMsg(int32_t fd , const unsigned char *msgBuf,
                        const int32_t msgLength, uint32_t timeout);

static void formMsgLengthHeader(unsigned char *msgLengthHeader,
                                int32_t msgLength);
static int32_t chkSocketConnectStatus(int32_t connectedFd);
static int32_t handshakeProcessReq(const unsigned char *respBuf,
                                   int32_t payloadLength,
                                   FSMXmlHandShakeResp& respHandShakeXml);


///Any time we want a new cipher to be supported, just bump the
///MAX_SUPPORTED_CIPHERS and add one to the list. Since the length
///has 256 bytes long, I don't think that will ever overflow looking
///at the ciphers(1) manpage.
char supportedCiphers[MAX_SUPPORTED_CIPHERS] [MAX_SUPPORTED_CIPHER_LEN] =
                                                  { "DES-CBC-SHA",
                                                    "NULL-MD5",
                                                    "NULL-SHA",
                                                    "RC4-MD5",
                                                    "EXP-RC4-MD5",
                                                    "RC4-SHA" };

char FSMipString[INET6_ADDRSTRLEN + 1];
static int32_t fpsGenerateRandomData(unsigned char *randArr, int arrSize);

static int verify_callback(int ok, X509_STORE_CTX *ctx);
static std::string populateCiphers(void);
#if 0
static void lockCleanup(void);
#endif

///=========================================================
///Below functions are Utility functions. Writing some important
///functions from the top of my head.


//////////Static Function Defintion/////////////////////////
static unsigned long fpsthreadIdCb(void)
{
    unsigned long ret;

    ret = (unsigned long)pthread_self();
    return(ret);
}

static void sslLockCb(int mode, int id, const char *file, int line)
{
  if (mode & CRYPTO_LOCK) {
    pthread_mutex_lock(&(sslLocks[id]));
  }
  else {
    pthread_mutex_unlock(&(sslLocks[id]));
  }
}

static int32_t handshakeProcessReq(const unsigned char *respBuf,
                                   int32_t payloadLength,
                                   FSMXmlHandShakeResp& respHandShakeXml)
{
    ///Process handshake response. I am leaving this as of now since
    ///XML message processing will be done by Sandeep. Always return
    ///success for the time being.
    Result_t Result = RESULT_SUCCESS;
    FSMXmlRespHdr respHandShakeHdr;
    //FSMXmlHandShakeResp respHandShakeXml;

    char *respXmlBuf = new char[ payloadLength+1 ];

    memcpy(respXmlBuf,respBuf,payloadLength);
    respXmlBuf[payloadLength] = '\0';

    char *pSavePtr = NULL;

    /* Get handshake resp header and validate the fields */
    char *pBuf = strtok_r(respXmlBuf,"\n", &pSavePtr);

    fprintf (stderr, "HANDSHAKE HDR:\n%s\n. [0x%p] %s:%d\n",
            pBuf,pthread_self(),__FILE__,__LINE__);

    if ( 0 != respHandShakeHdr.getRespHdrFromXML( pBuf ) )
    {
        fprintf (stderr, "HANDSHAKE HDR:Schema parsing Failed\n. [0x%p] %s:%d\n",
               pthread_self(),__FILE__,__LINE__);
    }

    /* get handshake resp payload and validate the fields */
    pBuf = strtok_r(NULL,"\n", &pSavePtr);
    fprintf (stderr, "HANDSHAKE RESP:\n%s\n. [0x%p] %s:%d\n",
               pBuf,pthread_self(),__FILE__,__LINE__);

    if ( 0 != respHandShakeXml.getHandshakeRespPayloadFromXML( pBuf ) )
    {
        fprintf (stderr, "getHandshakeRespPayloadFromXML Failed\n. [0x%p] %s:%d\n",
                pthread_self(),__FILE__,__LINE__);
    }

Catch_Errors:
    delete [] respXmlBuf;
    return Result;
}
static int32_t chkMsgLengthFormat(const unsigned char *lengthHeader,
                                  int32_t *payloadLength)
{
    int32_t         msgLength     = 0;
    int32_t         hFormatLength = 0;

    if (NULL == lengthHeader) {
        fprintf (stderr, "LengthHeader buffer sent to this function is NULL"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    ///Make sure the first character is a quote
    if('"' != lengthHeader[0] || '"' != lengthHeader[EP_HEADER_LEN - 1]) {
        fprintf (stderr, "Length header that we got from FPolicy Server"
                   " doesn't contain the proper record marker [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    ///Now verify the content length
    memcpy(&msgLength, lengthHeader + 1, 4);
    ///Change this length to host format.
    hFormatLength = ntohl(msgLength);
    ///Make sure the length is within the max range.
    if (hFormatLength > MAX_EP_NOTIFICATION_LEN) {
        fprintf (stderr, "Length[%d] that we got from FPolicy Server"
                   " is more than MAX_EP_NOTIFICATION_LEN notification "
                   "Length [0x%p] %s:%d\n", hFormatLength, pthread_self(), __FILE__,
                   __LINE__);
        return(-1);
    }
    fprintf (stderr, "LengthHeader buffer sent [%s] and length is[%d]"
               "[0x%p] %s:%d\n", lengthHeader, hFormatLength,pthread_self(),
               __FILE__, __LINE__);
    ///Got length which can be used.
    *payloadLength = hFormatLength;
    return(0);
}

static void formMsgLengthHeader(unsigned char *msgLengthHeader,
                                int32_t msgLength)
{
    int32_t    lengthNwFormat = 0;
    ///Add the record marker at the beginning and end of the buffer.
    msgLengthHeader[0] = '"';
    msgLengthHeader[EP_HEADER_LEN - 1] = '"';
    lengthNwFormat = htonl(msgLength);

    ///Copy the length to msgLengthHeader
    memcpy(msgLengthHeader + 1, &lengthNwFormat, 4);
}

///The bottom most layer for sending message to FPolicy server.
///Return Number of bytes returned or -1. The caller must chk
///for both error message and the number of bytes it provided
///this function to write and the actual amount of bytes written.
static int32_t sslSendMsg(SSL  *ssl, const unsigned char *msgBuf,
                          int32_t msgLength, uint32_t timeout)
{
    ///At this point of time, I assume SSL handshake is done.
    struct timeval   endTime     = {};
    struct timeval   currentTime = {};
    int32_t  numBytesWritten = 0;
    int32_t  retval = 0;

    if (NULL == msgBuf) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message buffer sent is NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (msgLength <= 0) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message length sent not valid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (NULL == ssl) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "SSL structure sent is NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    gettimeofday(&endTime, NULL);
    endTime.tv_sec += timeout;

    ///We are writing to a non-blocking socket. We must try to write
    ///data in given timeout period. If we are not able to write the
    ///data we must return error. Need for different error values when
    ///data was not written in complete chunk.TBD. For now, I am
    ///returning generinc error message.
    do {
        numBytesWritten = SSL_write(ssl, msgBuf, msgLength);
        if (numBytesWritten == msgLength) {
            fprintf (stderr, "Successfully written the full message "
                       "of size[%d] [0x%p] %s:%d\n", numBytesWritten,
                       pthread_self(), __FILE__,__LINE__);
            break;
        }
        else {
            ///Try Again!!
            fprintf (stderr, "Successfully written partial message "
                       "of size[%d] [0x%p] %s:%d\n", numBytesWritten,
                       pthread_self(), __FILE__,__LINE__);
            ///SSL_get_error() wants the value returned by previous
            ///I/O function. So, passing numBytesWritten as second
            ///argument. The retval can be used in switch.
            retval = SSL_get_error(ssl, numBytesWritten);
            switch(retval)
            {
                case SSL_ERROR_WANT_WRITE :
                {
                    ///This is very usual. This means we have not written
                    ///the complete buffer and a part of the buffer is written.
                    ///What is unusual in case of SSL is that we must perform
                    ///the SSL_write() with the same buffer. Refer to the NOTE
                    ///section in SSL_write() manual page.
                    fprintf (stderr, "SSL_get_error returned with  "
                               "SSL_ERROR_WANT_WRITE flag.Partial data written"
                               "of size[%d] [0x%p] %s:%d\n", numBytesWritten,
                               pthread_self(), __FILE__,__LINE__);
                    break;
                }
                case SSL_ERROR_SYSCALL :
                {
                    ///Some I/O error was seen. As the man pages suggests
                    ///checking the errno.
                    if (EAGAIN == errno) {
                        ///This is usual. This might have been returned from
                        ///returned from select(). Just break and try again.
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data written"
                                   "of size[%d] errno[EAGAIN] [0x%p] %s:%d\n",
                                   numBytesWritten, pthread_self(), __FILE__,
                                   __LINE__);
                        break;
                    }
                    else if (EPIPE == errno) {
                        ////Transport connection is broken. return error.
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data written"
                                   "of size[%d] errno[EPIPE] [0x%p] %s:%d\n",
                                   numBytesWritten, pthread_self(), __FILE__,
                                   __LINE__);
                        return(-1);
                    } ///Can't think of any more error chk.
                    else {
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data written"
                                   "of size[%d] errno[%d] [0x%p] %s:%d\n",
                                   numBytesWritten, errno, pthread_self(),
                                   __FILE__,__LINE__);
                        return(-1);
                    } ///< Ending the else.
                } ///< Ending case SSL_ERROR_SYSCALL
                default :
                {
                     fprintf (stderr, "SSL_get_error returned with error with "
                             "switch default.Partial data written of"
                             " size[%d] retval[%d] errno[%d] [0x%p] %s:%d\n",
                             numBytesWritten, retval, errno, pthread_self(),
                             __FILE__,__LINE__);
                    return(-1);
                }
            }///< Ending SSL_get_error() switch.
        } ///< Ending else with numBytesWritten != msgLength

        ///Calculate the current time and see the difference.
        gettimeofday(&currentTime, NULL);

    } while(timercmp(&endTime, &currentTime, >));
    ///We are here because of two reasons.
    ///1. We wrote the amount of data required. OR
    ///2. We timedout.
    if ((numBytesWritten < msgLength) && !(timercmp(&endTime, &currentTime, >))) {
        fprintf (stderr, "Unsuccessful in writing message.Wrote msg "
                   "of size[%d] [0x%p] %s:%d\n", numBytesWritten,
                   pthread_self(), __FILE__,__LINE__);
        return(numBytesWritten);
    }
    return(numBytesWritten);
}

///Note that this function won't read all the pending buffer
///present in SSL. This function will only read as much informtion
///it is asked to. It is the responsiblity of the caller to
///determine if any pending buffer is present by calling
///SSL_pending().
static int32_t sslRecvMsg(SSL *ssl, unsigned char *msgBuf, int32_t msgLength,
                          uint32_t timeout)
{
    ///At this point of time, I assume SSL handshake is done.
    struct timeval   endTime     = {};
    struct timeval   currentTime = {};
    int32_t  numBytesRead    = 0;
    int32_t  retval = 0;
    int32_t  sslerr = 0;

    if (NULL == msgBuf) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message buffer sent to fill NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (msgLength <= 0) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message length sent not valid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (NULL == ssl) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "SSL structure sent is NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    //gettimeofday(&startTime, NULL);
    gettimeofday(&endTime, NULL);
    endTime.tv_sec += timeout;

    do {
        retval = SSL_read(ssl, msgBuf + numBytesRead,
                          msgLength - numBytesRead);

        if (retval < 0) {
            ///Try Again!!
            fprintf (stderr, "Error encountered while reading "
                       "the msg using SSL_read [0x%p] %s:%d\n",
                       pthread_self(), __FILE__,__LINE__);
            ///SSL_get_error() wants the value returned by previous
            ///I/O function. So, passing numBytesRead as second
            ///argument. The retval can be used in switch.
            sslerr = SSL_get_error(ssl, retval);
            switch(sslerr)
            {
                case SSL_ERROR_WANT_READ :
                {
                    ///This is very usual. This means we have not read
                    ///the complete msgLength and a part of the message buffer
                    ///is read and SSL needs to read more bytes for n/w buffer
                    fprintf (stderr, "SSL_get_error returned with  "
                               "SSL_ERROR_WANT_READ flag.Partial data read"
                               "of size[%d] [0x%p] %s:%d\n", numBytesRead,
                               pthread_self(), __FILE__,__LINE__);
                    ///Reset the retval
                    retval = 0;
                    break;
                }
                case SSL_ERROR_SYSCALL :
                {
                    ///Some I/O error was seen. As the man pages suggests
                    ///checking the errno.
                    if (EAGAIN == errno) {
                        ///This is usual. This might have been returned from
                        ///from select(). Just break and try again.
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data read"
                                   "of size[%d] errno[EAGAIN] [0x%p] %s:%d\n",
                                   numBytesRead, pthread_self(), __FILE__,
                                   __LINE__);
                        ///Reset the retval.
                        retval = 0;
                        break;
                    }
                    else if (EPIPE == errno) {
                        ////Transport connection is broken. return error.
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data read"
                                   "of size[%d] errno[EPIPE] [0x%p] %s:%d\n",
                                   numBytesRead, pthread_self(), __FILE__,
                                   __LINE__);
                        return(-1);
                    } ///Can't think of any more error chk.
                    else {
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag.Partial data read"
                                   "of size[%d] errno[%d] [0x%p] %s:%d\n",
                                   numBytesRead, errno, pthread_self(),
                                   __FILE__,__LINE__);
                        return(-1);
                    } ///< Ending the else.
                } ///< Ending case SSL_ERROR_SYSCALL
                default :
                {
                    fprintf (stderr, "SSL_get_error returned with error with"
                            " switch default.Partial data read of"
                            " size[%d] retval[%d] errno[%d] [0x%p] %s:%d\n",
                            numBytesRead, retval, errno, pthread_self(),
                            __FILE__,__LINE__);
                    return(-1);
                }
            } ///< Ending SSL_get_error() switch.
        } ///< If retval < 0
        else if (0 == retval) {
            ///SSL manpage is doesn't say much, we are here
            ///because of clean shutdown or peer closed the
            ///the connection. Let's read the
            ///the connection.
            sslerr = SSL_get_error(ssl, retval);
            switch(sslerr)
            {
                case SSL_ERROR_ZERO_RETURN :
                {
                    fprintf (stderr, "Peer closed the connection cleanly"
                            "Error is [%d] [0x%p] %s:%d\n", sslerr,
                            pthread_self(),__FILE__,__LINE__);
                    return(-1);
                }
                case SSL_ERROR_SYSCALL :
                {
                    if (EPIPE == errno) {
                        fprintf (stderr, "SSL_get_error returned with  "
                                "SSL_ERROR_SYSCALL flag. EPIPE Received"
                                "errno[EPIPE] [0x%p] %s:%d\n",
                                pthread_self(), __FILE__, __LINE__);
                        return(-1);
                    }
                    else {
                        fprintf (stderr, "SSL_read returned zero and get_error "
                                "returned [%d] errno[%d] [0x%p] %s:%d\n", sslerr,
                                errno, pthread_self(),__FILE__,__LINE__);
                        return(-1);
                    }
                }
                default :
                {
                    fprintf (stderr, "Peer closed the connection: Default handling "
                            "Error is [%d] [0x%p] %s:%d\n", sslerr,
                            pthread_self(),__FILE__,__LINE__);
                    return(-1);
                }
            }
        }
        numBytesRead += retval;

        if (numBytesRead == msgLength) {
            fprintf (stderr, "Successfully Read the full message "
                       "of size[%d] [0x%p] %s:%d\n", numBytesRead ,
                       pthread_self(), __FILE__,__LINE__);
            break;
        }
        ///Calculate the current time and see the difference.
        gettimeofday(&currentTime, NULL);

    } while(timercmp(&endTime, &currentTime, >));
    ///We are here because of two reasons.
    ///1. We wrote the amount of data required. OR
    ///2. We timedout.
    if ((numBytesRead < msgLength) && !(timercmp(&endTime, &currentTime, >))) {
        fprintf (stderr, "Unsuccessful in reading message.Read msg "
                   "of size[%d] [0x%p] %s:%d\n", numBytesRead,
                   pthread_self(), __FILE__,__LINE__);
        return(numBytesRead);
    }
    return(numBytesRead);
}

static int32_t readMsg(int32_t fd ,unsigned char *msgBuf, int32_t msgLength,
                       uint32_t timeout)
{
    ///At this point of time, I assume SSL handshake is done.
    struct timeval   endTime     = {};
    struct timeval   currentTime = {};
    int32_t  numBytesRead    = 0;
    int32_t  retval = 0;

    if (NULL == msgBuf) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message buffer sent to fill NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (msgLength <= 0) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message length sent not valid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (INVALID_FD == fd) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "File descriptor is invalid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    //gettimeofday(&startTime, NULL);
    gettimeofday(&endTime, NULL);
    endTime.tv_sec += timeout;

    do {
        retval = read(fd, msgBuf + numBytesRead, msgLength - numBytesRead);

        if (retval == -1) {
            if (EAGAIN == errno) {
                retval = 0;
            }
            else {
                fprintf (stderr, "Read returned error with errno[%d] "
                           "[0x%p] %s:%d\n", errno, pthread_self(),
                           __FILE__,__LINE__);
                return(-1);
            }
        }
        else if(0 == retval) { ///connection is closed.
            fprintf (stderr, "Read returned error with errno[%d] "
                       "[0x%p] %s:%d\n", errno, pthread_self(),
                       __FILE__,__LINE__);
            return(-1);
        }
        numBytesRead += retval;

        if (numBytesRead == msgLength) {
            fprintf (stderr, "Successfully Read the full message "
                       "of size[%d] [0x%p] %s:%d\n", numBytesRead ,
                       pthread_self(), __FILE__,__LINE__);
            break;
        }

        ///Calculate the current time and see the difference.
        gettimeofday(&currentTime, NULL);

    } while(timercmp(&endTime, &currentTime, >));
    ///We are here because of two reasons.
    ///1. We read the amount of data required. OR
    ///2. We timedout.
    if ((numBytesRead < msgLength) && !(timercmp(&endTime, &currentTime, >))) {
        fprintf (stderr, "Unsuccessful in reading message. Read msg "
                   "of size[%d] [0x%p] %s:%d\n", numBytesRead,
                   pthread_self(), __FILE__,__LINE__);
        return(numBytesRead);
    }

    fprintf (stderr, "Returning from read with [%d] bytes read. "
               "[0x%p] %s:%d\n", numBytesRead, pthread_self(), __FILE__,
               __LINE__);

    return(numBytesRead);
}

static int32_t writeMsg(int32_t fd , const unsigned char *msgBuf,
                        const int32_t msgLength, uint32_t timeout)
{
    ///At this point of time, I assume SSL handshake is done.
    struct timeval   endTime     = {};
    struct timeval   currentTime = {};
    int32_t  numBytesWrote = 0;
    int32_t  retval = 0;

    if (NULL == msgBuf) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message buffer is NULL [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (msgLength <= 0) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "Message length sent not valid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (INVALID_FD == fd) {
        ///Need to write appropriate error code. Will do that later.
        fprintf (stderr, "File descriptor is invalid [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    //gettimeofday(&startTime, NULL);
    gettimeofday(&endTime, NULL);
    endTime.tv_sec += timeout;

    do {
        retval = write(fd, msgBuf + numBytesWrote, msgLength - numBytesWrote);

        if (retval == -1) {
            if (EAGAIN == errno) {
                retval = 0;
            }
            else {
                fprintf (stderr, "Write returned error with errno[%d] "
                           "[0x%p] %s:%d\n", errno, pthread_self(),
                           __FILE__,__LINE__);
                return(-1);
            }
        }
        numBytesWrote += retval;

        if (numBytesWrote == msgLength) {
            fprintf (stderr, "Successfully Wrote the full message "
                       "of size[%d] [0x%p] %s:%d\n", numBytesWrote,
                       pthread_self(), __FILE__,__LINE__);
            break;
        }

        ///Calculate the current time and see the difference.
        gettimeofday(&currentTime, NULL);

    } while(timercmp(&endTime, &currentTime, >));
    ///We are here because of two reasons.
    ///1. We wrote the amount of data required. OR
    ///2. We timedout.
    if ((numBytesWrote < msgLength) && !(timercmp(&endTime, &currentTime, >))) {
        fprintf (stderr, "Unsuccessful in writing message.Wrote msg "
                   "of size[%d] [0x%p] %s:%d\n", numBytesWrote,
                   pthread_self(), __FILE__,__LINE__);
        return(numBytesWrote);
    }

    fprintf (stderr, "Returning from write with [%d] bytes written. "
               "[0x%p] %s:%d\n", numBytesWrote, pthread_self(), __FILE__,
               __LINE__);

    return(numBytesWrote);
}

static int32_t chkSocketConnectStatus(int32_t connectedFd)
{
    struct sockaddr_storage peerName;
    socklen_t length = sizeof(peerName);
    char      ipString[INET6_ADDRSTRLEN + 1];
    uint32_t  port   = 0;
    int32_t   retval = 0;

    memset(&peerName, 0, sizeof(peerName));
    memset(ipString, '\0', INET6_ADDRSTRLEN + 1);
    ///Issue a getpeername() call and see the error value.
    retval = getpeername(connectedFd, (struct sockaddr *) &peerName,
                         &length);
    if (retval != 0) {
        fprintf (stderr, "getpeername failed. Socket is not connected"
                   "[0x%p] %s:%d\n", pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    ///It is not a bad idea to print a log message with peername.
    ///Do we have a separate type for mapped. Verify.
    if (peerName.ss_family == AF_INET) {
        struct sockaddr_in *ipv4SockAddr = (struct sockaddr_in *)&peerName;
        port = ntohs(ipv4SockAddr->sin_port);
        inet_ntop(AF_INET, &(ipv4SockAddr->sin_addr), ipString,
                  sizeof(ipString));
    }
    else { ///IPV6 Address.
        struct sockaddr_in6 *ipv6SockAddr = (struct sockaddr_in6 *)&peerName;
        port = ntohs(ipv6SockAddr->sin6_port);
        inet_ntop(AF_INET6, &(ipv6SockAddr->sin6_addr), ipString,
                  sizeof(ipString));
    }
    fprintf (stderr, "getpeername() returned IP string[%s] and port[%d]"
               "[0x%p] %s:%d\n", ipString, port, pthread_self(),
               __FILE__,__LINE__);

    memset(FSMipString, '\0', sizeof(FSMipString));
    strncpy(FSMipString, ipString, sizeof(FSMipString));
    FSMipString[INET6_ADDRSTRLEN] = '\0';

    return(0);
}

static int32_t fpsGenerateRandomData(unsigned char *randArr, int arrSize)
{
    int32_t  ret = 0;

    ret = RAND_pseudo_bytes(randArr, arrSize);
    if (ret < 0) {
        fprintf (stderr, "RAND_pseudo_bytes Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ret = -1;
    }
    return ret;
}

static int verify_callback(int ok, X509_STORE_CTX *ctx)
{
    char *s, buf[256];

    s = X509_NAME_oneline(X509_get_subject_name(ctx->current_cert),
                          buf,256);
    if (s != NULL) {
        if (ok) {
            fprintf(stderr,"depth=%d %s\n",
                    ctx->error_depth,buf);
        }
        else {
            fprintf(stderr,"depth=%d error=%d %s\n",
                    ctx->error_depth,ctx->error,buf);
        }
    }
    return(ok);
}

///Function to populate the cipher in a format which can be used by
///openssl.
static std::string populateCiphers(void)
{
    ///Populate cipher list with colon(:) seprated.
    std::stringstream  cipherStream;
    std::string        cipherString;
    uint32_t           counter = 0;

    for (counter = 0; counter < MAX_SUPPORTED_CIPHERS; counter++) {
        cipherStream << supportedCiphers[counter] << ":";
    }
    cipherString = cipherStream.str();

    return(cipherString);
}


//////////Extern Functions/////////////////////////

int32_t isIPAddress(char *host, addressType_e& type)
{
    struct addrinfo hints;
    struct addrinfo *res = NULL;

    memset(&hints, '\0', sizeof(hints));

    hints.ai_family   = AF_INET6;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags    = AI_NUMERICHOST;

    ///Now call getaddrinfo to see if it success.
    if (getaddrinfo(host, NULL, &hints, &res) == 0) {
        ///IPV6 Address.
        type = IPV6TYPE;
        freeaddrinfo(res);
        res = NULL;
        return 0;
    }

    ///Check if it is a V4 Address.
    hints.ai_family = AF_INET;
    if (getaddrinfo(host, NULL, &hints, &res) == 0) {
        ///IPV4 Address.
        type = IPV4TYPE;
        freeaddrinfo(res);
        res = NULL;
        return 0;
    }

    ///Address is a host name.
    type = HOSTNAME_TYPE;
    return 0;
}

int32_t FSMConnection::fpServerSslInit(const char *CACertificate,
                                       const char *PublicCertificate,
                                       const char *PvtKey,
                                       const char *PvtPasswd)
{
    SSL_METHOD           *method;
    unsigned char        buf[RANDOM_BUF_LEN];
    int                  ret;

    ///Check input parameters being NULL.

    ///Create a BIO for stderr. An error write
    ///context. BIO_NOCLOSE means when BIO is
    ///freed, stream is not closed.
    bio_err = BIO_new_fp(stderr, BIO_NOCLOSE);

    SSL_library_init();
    SSL_load_error_strings(); ///< readable error messages
    if ((ret = fpsGenerateRandomData(buf, RANDOM_BUF_LEN)) < 0) {
        fprintf (stderr, "Error in random number gen [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        bio_err = NULL;
        return(-1);
    }
    RAND_seed(buf, RANDOM_BUF_LEN);
    ///Make sure we have good random number
    if (0 == RAND_status()) {
        fprintf (stderr, "No good random number [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        bio_err = NULL;
        return(-1);
    }
    ///Will support only V3 method in the first release. Based on
    ///request (if any), think of supporting other versions later.
    method = NULL;//SSLv3_method();

    ///Create a new context.
    if (NULL == (_sslContext=SSL_CTX_new(method))) {
        fprintf (stderr, "SSL_CTX_new Failed. [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        bio_err = NULL;
        return (-1);
    }

    std::string cipherSuites = populateCiphers();

    ///Set the cipher suite. Defualt cipher suite is DES-CBC-SHA. Going
    ///forward, I will have a list of cipher separated by colon(:).
    if (SSL_CTX_set_cipher_list(_sslContext, cipherSuites.c_str()) == 0) {
        fprintf (stderr, "SSL_CTX_set_cipher_list Failed. [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }

    ///Set the options to have all the workarounds. Good to have this.
    ///Refer to SSL documentation.
    SSL_CTX_set_options(_sslContext, SSL_OP_ALL);

    ///Check later whether we need to use SSL_CTX_set_session_cache_mode
    ///calls.

    ///Load the public cert and pvt key. Logic for forming the path to load
    ///the cert will go here. Will construct path later after having a
    ///discussion with Naitik. To test, I will load the file directly
    ///from the absolute path.
    if (!SSL_CTX_use_certificate_file(_sslContext , PublicCertificate,
                                      SSL_FILETYPE_PEM)) {
        fprintf (stderr, "SSL_CTX_use_certificate_file Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }

    ///Load the private key. As of SN.0, private key is not encrypted
    ///with any password. Once that is in place we need to register a
    ///callback for password. Refer to SSL_CTX_set_default_passwd_cb()
    ///manpage in future.
    if (!SSL_CTX_use_PrivateKey_file(_sslContext, PvtKey,
                                     SSL_FILETYPE_PEM)) {
        fprintf (stderr, "SSL_CTX_use_PrivateKey_file Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }

    ///It is good to verify the public key with the loaded certificate.
    ///Refer to manual page.
    if (!SSL_CTX_check_private_key(_sslContext)) {
        fprintf (stderr, "SSL_CTX_check_private_key Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }
    ///Load the CA certificate we trust. In ONTAP, we don't store the
    ///merged CA public certificates. We store certificates in a
    ///directory with each CA public certificates with different
    ///filename. For details look at the manual page for
    ///SSL_CTX_load_verify_locations. For testing purpose, I am using
    ///the CA certificate which is predefined.
    if (!SSL_CTX_load_verify_locations(_sslContext, CACertificate, NULL)) {
        fprintf (stderr, "SSL_CTX_load_verify_locations Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }

    ///Set the verify depth.In the first release, I don't wan't to go
    ///for chain. Make life simple and keep some work for next
    ///releases...
    SSL_CTX_set_verify_depth(_sslContext, 1);

    ///Set the verify call back mode and call back function. This is the
    ///call which determines whether both client and server needs to be
    ///authenticated. As of now, I have implmented a basic verify_func.
    ///will override that once the sample works!
    if (0 == isMutualAuth) {
        SSL_CTX_set_verify(_sslContext, SSL_VERIFY_NONE ,
                           verify_callback);
    }
    else { ///For any other value, I do mutual authentication.
        SSL_CTX_set_verify(_sslContext, SSL_VERIFY_PEER |
                           SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
                           verify_callback);
    }

    ///Huh...what more...Tired of this SSL setup. Can someone give me a
    ///training on this? Good that we have atleast some sample app shipped
    ///with SSL library. Otherwise, I wonder how life would have been with
    ///this little document by OpenSSL. Now, some thread considerations.
    ///How many locks?? Look at the manual page of CRYPTO_num_locks() to
    ///unerstand what will happen if we don't provide below...

    int32_t numLocks = CRYPTO_num_locks();
    sslLocks = (pthread_mutex_t *)OPENSSL_malloc(sizeof(pthread_mutex_t) *
                                                 numLocks);
    if (NULL == sslLocks) {
        fprintf (stderr, "OPENSSL_malloc Failed. [0x%p] "
                   "%s:%d\n", pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        (void) BIO_flush(bio_err);
        BIO_free(bio_err);
        SSL_CTX_free(_sslContext);
        _sslContext = NULL;
        bio_err = NULL;
        return(-1);
    }
    ///Initialize the locks.
    for (int32_t count=0; count < numLocks; count++) {
        pthread_mutex_init(&(sslLocks[count]), NULL);
    }
    ///Do we need a lock count as mentioned in the test app at the
    ///at .../freebsd/crypto/openssl/crypto/threads/mttest.c?? --Verify

    CRYPTO_set_id_callback((unsigned long (*)())fpsthreadIdCb);
    CRYPTO_set_locking_callback(sslLockCb);

    ///Time to return with all setup done.
    return (0);
}

int32_t FSMConnection::recvMsg(unsigned char **respBuf, int32_t *respLength)
{
    int32_t      retval = 0;

    ///Read the message length header.
    if (true == _sslAuthEnabled) {
        retval = sslRecvFSMXmlResp(respBuf, respLength);
        if ( -1 == retval ) {
            fprintf (stderr, "sslRecvFSMXmlResp failed to recv. the XML"
                    "response. [0x%p] %s:%d\n", pthread_self(),
                    __FILE__,__LINE__);
        }
    }
    else {
        retval = tcpRecvFSMXmlResp(respBuf, respLength);
        if ( -1 == retval ) {
            fprintf (stderr, "tcpRecvFSMXmlResp failed to recv the XML"
                    "response. [0x%p] %s:%d\n", pthread_self(),
                    __FILE__,__LINE__);
        }
    }
    return(retval);
}

int32_t FSMConnection::sendMsg(FSMXmlReq &xmlReqToSend)
{
    int32_t     retval = 0;
    ///Send the request to FPolicy server and wait for response or timeout.
    ///In this case let the thread of execution do send and wait for response.
    if (true == _sslAuthEnabled) {
        retval = sslSendFSMXmlReq(xmlReqToSend);
        if ( -1 == retval ) {
            fprintf (stderr, "sslSendFSMXmlReq failed to send the request"
                    "XML request. [0x%p] %s:%d\n", pthread_self(),
                    __FILE__,__LINE__);
        }
    }
    else {
        retval = tcpSendFSMXmlReq(xmlReqToSend);
        if ( -1 == retval ) {
            fprintf (stderr, "tcpSendFSMXmlReq failed to send the request"
                    "XML request. [0x%p] %s:%d\n", pthread_self(),
                    __FILE__,__LINE__);
        }
    }
    return(retval);
}

int32_t FSMConnection::doFpolicyHandshake(void)
{
    int32_t            retval     = 0;
    unsigned char      *reqBuf   = NULL;
    int32_t            reqLength = 0;
    ///With the connected socket, we should recv. handshake req from
    ///FSM. To make sure I have a connected socket,
    ///I am using getpeername(). This can be seen as an extra
    ///check but I want to double check.
    retval = chkSocketConnectStatus(_connectedFd);
    if (retval != 0) {
        ///Socket is not connected yet or got disconnected!!!
        fprintf (stderr, "chkSocketConnectStatus failed. "
                   "Socket is not connected [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    ///Wait for handshake request from FSM..
    if (_sslAuthEnabled) {
        retval = sslHandshakeRecvMsg(&reqBuf, &reqLength);
        if (-1 == retval) {
            fprintf (stderr, "sslHandshakeRecvMsg returned error while"
                       "receving handshake response from FPolicy server "
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            return(-1);
        }
    }
    else {
        retval = tcpHandshakeRecvMsg(&reqBuf, &reqLength);
        if (-1 == retval) {
            fprintf (stderr, "tcpHandshakeRecvMsg returned error while"
                       "receving handshake response from FPolicy server "
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            return(-1);
        }
    }

    FSMXmlHandShakeResp respHandShakeXml;
    ///Parse the handshake request.
    retval = handshakeProcessReq(reqBuf, reqLength, respHandShakeXml);
    if (0 != retval) {
        fprintf (stderr, "handshakeProcessReq returned error while"
                   "processing response buffer from FPolicy server "
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);

        if (reqBuf) {
            free(reqBuf);
            reqBuf = NULL;
        }

        return(-1);
    }
    std::cout << "*****************************************" << endl;
    std::cout << respHandShakeXml.getVserverUUID().c_str() << endl;
    std::cout << "*****************************************" << endl;

    FSMXmlReq *handshakeResp = populateXmlHandshakeResp(respHandShakeXml.getVserverUUID().c_str(),
                                                        respHandShakeXml.getSessionId().c_str(),
                                                        respHandShakeXml.getPolicyName().c_str(),
                                                       "1.0");

    sessionId = respHandShakeXml.getSessionId();

    ///Set the global sessionId. Will be used while backpressure is sent
    strncpy(_sessionId, respHandShakeXml.getSessionId().c_str(), MAX_SESSION_ID_LEN);
    _sessionId[MAX_SESSION_ID_LEN] = '\0';


    ///Send the handshake notfication to FPolicy server. For this construct a
    ///handshake notification with list of version supported by FSM.
    ///TBD: Create a session.

    FSMXmlReq *fpsHandshakeHeader = populateXmlHeaderMsg(
                                            NEGO_MSG_RESP,
                                            handshakeResp->getXmlMsgLength(),
                                            FORMAT_XML);
    ///Concatenate both the request with separator in. TBD: For testing
    ///purpose, I am adding a null byte at the end. Need to remove this
    ///during the final checkin.
    FSMXmlReq     xmlReqToSend;
    std::string   separator("\n\n");
    std::string   nullString;
    nullString += '\0'; ///< Add a null character to nullString.

    xmlReqToSend = (*fpsHandshakeHeader) + separator + (*handshakeResp)
                    + nullString;

    fprintf (stderr, "Handshake Response sent to FSM is [%s] of length [%d]",
            xmlReqToSend.getXmlMsgBuf(), xmlReqToSend.getXmlMsgLength(),
            "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);

    ///At the point, we don't need handshakeReq & fpsHandshakeHeader.
    delete(handshakeResp);
    delete(fpsHandshakeHeader);

    ///Send the request to FPolicy server and wait for response or timeout.
    ///In this case let the thread of execution do send and wait for response.
    if (true == _sslAuthEnabled) {
        retval = sslSendFSMXmlReq(xmlReqToSend);
    }
    else {
        retval = tcpSendFSMXmlReq(xmlReqToSend);
    }

    if (retval != 0) {
        fprintf (stderr, "sslHandshakeSendResp returned error while"
                   "sending the handshake message resp to FSM"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);

        if (reqBuf) {
            free(reqBuf);
            reqBuf = NULL;
        }

        return(-1);
    }

    if (reqBuf) {
        free(reqBuf);
        reqBuf = NULL;
    }

    return(0);
    ///fps handshake is done!!
}

int32_t FSMConnection::sslHandshakeRecvMsg(unsigned char **respBuf,
                                           int *respLength)
{
    int32_t         retval = 0;
    fd_set          readFd;
    int             highFd = 0;
    int             numFds = 0;
    struct timeval  completionTime   = {};
    struct timeval  currentTime      = {};
    struct timeval  selectTimeout    = {};
    ///We don't want HeaderBuf null terminated.
    unsigned char   lengthHeaderBuf[EP_HEADER_LEN];
    unsigned char   *respPayload = NULL;

    ///Wait for fpsHandshakeTimeout for a response from
    ///FPolicy server. The select can be a blocking one for the
    ///timeout period.
    gettimeofday(&completionTime, NULL);
    completionTime.tv_sec += fpsHandshakeTimeout;

    do {
        FD_ZERO(&readFd);
        FD_SET(_connectedFd, &readFd);
        highFd = _connectedFd + 1;

        gettimeofday(&currentTime, NULL);
        ///timersub manual page doesn't talk about the case when
        ///current time has gone ahead of completion time. But the man
        ///manpage says that timersub can be used in gettimeofday().
        timersub(&completionTime, &currentTime, &selectTimeout);

        numFds = select( highFd+1, &readFd, NULL, NULL, &selectTimeout);
        if (-1 == numFds) {
            ///Look at the error in case it is because of interrupted signal
            if(EINTR == errno) {
                continue;
            }
            else {
                fprintf (stderr, "select returned error with errno[%d]"
                           "[0x%p] %s:%d\n", errno, pthread_self(), __FILE__,
                           __LINE__);
                return(-1);
            }
        }
        if (0 == numFds) {
            ///Time expired.
            fprintf (stderr, "select returned with timeout hit."
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            return(-1);
        }
        if (FD_ISSET(_connectedFd, &readFd)) { ///Success case.
            fprintf (stderr, "select returned true with socket read."
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            break;
        }
    } while(timercmp(&completionTime, &currentTime, >));

    memset(lengthHeaderBuf, '\0', EP_HEADER_LEN);
    ///Socket is ready to be read. Read the length header for the message
    ///length. Revisit the read timeout of 1sec.
    (void) pthread_mutex_lock(&_connSslMutex);
    retval = sslRecvMsg(_connSsl, lengthHeaderBuf, EP_HEADER_LEN, READ_TIMEOUT);
    (void) pthread_mutex_unlock(&_connSslMutex);

    if (-1 == retval) {
        fprintf (stderr, "sslRecvMsg returned error while reading the"
                   " handshake message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    if (EP_HEADER_LEN != retval) {
        fprintf (stderr, "sslRecvMsg read partial data than"
                   " handshake message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    ///Chk the format of length header buffer.
    int32_t     payloadLength = 0;
    retval = chkMsgLengthFormat(lengthHeaderBuf, &payloadLength);
    if (-1 == retval) {
        fprintf (stderr, "chkMsgLengthFormat returned error as handshake"
                   " message length received from FPolicy server is improper"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    respPayload = (unsigned char *) malloc(payloadLength * sizeof(unsigned char));
    ///Read the message body.
    (void) pthread_mutex_lock(&_connSslMutex);
    retval = sslRecvMsg(_connSsl, respPayload, payloadLength, READ_TIMEOUT);
    (void) pthread_mutex_unlock(&_connSslMutex);
    if (-1 == retval) {
        fprintf (stderr, "sslRecvMsg returned error while reading the"
                   " handshake message payload from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }

    if (payloadLength != retval) {
        fprintf (stderr, "sslRecvMsg read partial data than"
                   " handshake message buffer from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }
    *respLength = payloadLength;
    *respBuf    = respPayload;
    return(0);
}

int32_t FSMConnection::disconnectFSM(void)
{
    int32_t     retval = 0;
    if (1 == _sslAuthEnabled) {
        retval = disconnectFSMOverSsl();
        if (-1 == retval) {
            fprintf (stderr, "acceptFsmConnectionOverSsl failed.[0x%p] %s:%d\n",
                pthread_self(), __FILE__,__LINE__);
            return(retval);
        }
    }
    else {
        retval = disconnectFSMOverTcp();
        if (-1 == retval) {
            fprintf (stderr, "acceptFsmConnectionOverTcp failed.[0x%p] %s:%d\n",
                pthread_self(), __FILE__,__LINE__);
            return(retval);
        }
    }
}

///TBD:This needs some more coding since we need to flush the data which
///is present in SSL buffer. Since this is a corner case, will take that
///when timer permits.
int32_t FSMConnection::disconnectFSMOverSsl(void)
{
    struct timeval     endTime     = {};
    struct timeval     currentTime = {};
    int32_t            retval      = 0;
    int32_t            sslerr      = 0;

    ///If SSL is enabled, shutdown the SSL connection.
    gettimeofday(&endTime, NULL);
    endTime.tv_sec += SSL_SHUTDOWN_TIME;

    ///We are shutting down a non-blocking socket. We must try to shutdown
    ///in given timeout period. If we are not able to shutdown in the
    ///timemout, we must close the connection. We want to close the connection
    ///gracefully but it MUST be closed within the timeout. This is "one way"
    ///close.
    do {
        retval = SSL_shutdown(_connSsl);
        if (0 == retval) {
            fprintf (stderr, "SSL_shutdown() returned 0 while closing conn "
                       "to server[%s] [0x%p] %s:%d\n", _FSMIpAddress,
                       pthread_self(), __FILE__,__LINE__);
            ///SSL_get_error() wants the value returned by previous
            ///I/O function. So, passing retval as second
            ///argument.
            sslerr = SSL_get_error(_connSsl, retval);
            switch(sslerr)
            {
                case SSL_ERROR_NONE :
                {
                    fprintf (stderr, "SSL_get_error returned with  "
                               "SSL_ERROR_NONE flag. [0x%p] "
                               "%s:%d\n", pthread_self(), __FILE__,__LINE__);
                    goto force_close;
                    //break;
                }
                case SSL_ERROR_WANT_READ  :
                {
                    ///TBD : Need to have logic to read and throw the data.
                    fprintf (stderr, "SSL_get_error returned with  "
                               "SSL_ERROR_WANT_READ flag. FPolicy Server"
                               " is still writing data to the socket"
                               " Need to read and throw the data [0x%p] "
                               "%s:%d\n", pthread_self(), __FILE__,__LINE__);
                    goto force_close;
                    //break;
                }
                case SSL_ERROR_WANT_WRITE :
                {
                    fprintf (stderr, "SSL_get_error returned with  "
                               "SSL_ERROR_WANT_WRITE flag.[0x%p] %s:%d\n",
                               pthread_self(), __FILE__,__LINE__);
                    goto force_close;
                    //break;
                }
                case SSL_ERROR_SYSCALL :
                {
                    ///Man page says don't trust this error!
                        fprintf (stderr, "SSL_get_error returned with  "
                                   "SSL_ERROR_SYSCALL flag. errno[%d] [0x%p] "
                                   "%s:%d\n", errno, pthread_self(), __FILE__,
                                   __LINE__);
                        goto force_close;
                        //break;
                } ///< Ending case SSL_ERROR_SYSCALL
            } ///< Ending SSL_get_error() switch.
        } ///< Ending retval == 0
        else if ( -1 == retval ) {
            fprintf (stderr, "SSL_shutdown returned(-1) fatal  "
                       "error .[0x%p] %s:%d\n", pthread_self(),
                       __FILE__,__LINE__);
            goto force_close;
        }
        else { ///The return value is 1
            fprintf (stderr, "SSL_shutdown returned(1). Both the party "
                       "sent shutdown.[0x%p] %s:%d\n", pthread_self(),
                       __FILE__,__LINE__);
            goto force_close;
        }

        ///Calculate the current time and see the difference.
        gettimeofday(&currentTime, NULL);
    } while(timercmp(&endTime, &currentTime, >));


force_close :
    SSL_free(_connSsl);
    _connSsl = NULL;
    if (_connectedFd != INVALID_FD) {
        close(_connectedFd);
        _connectedFd = INVALID_FD;
    }
    _connBIO = NULL;
    return(0);
}

int32_t FSMConnection::disconnectFSMOverTcp(void)
{
    if (_connectedFd != INVALID_FD) {
        close(_connectedFd);
        _connectedFd = INVALID_FD;
    }

    return(0);
}

int32_t FSMConnection::tcpHandshakeRecvMsg(unsigned char **respBuf,
                                           int *respLength)
{
    int32_t         retval = 0;
    fd_set          readFd;
    int             highFd = 0;
    int             numFds = 0;
    struct timeval  completionTime   = {};
    struct timeval  currentTime      = {};
    struct timeval  selectTimeout    = {};
    ///We don't want HeaderBuf null terminated.
    unsigned char   lengthHeaderBuf[EP_HEADER_LEN];
    unsigned char   *respPayload = NULL;

    ///Wait for fpsHandshakeTimeout for a response from
    ///FPolicy server. The select can be a blocking one for the
    ///timeout period.
    gettimeofday(&completionTime, NULL);
    completionTime.tv_sec += fpsHandshakeTimeout;

    do {
        FD_ZERO(&readFd);
        FD_SET(_connectedFd, &readFd);
        highFd = _connectedFd + 1;

        gettimeofday(&currentTime, NULL);
        ///timersub manual page doesn't talk about the case when
        ///current time has gone ahead of completion time. But the man
        ///manpage says that timersub can be used in gettimeofday().
        timersub(&completionTime, &currentTime, &selectTimeout);

        numFds = select( highFd+1, &readFd, NULL, NULL, &selectTimeout);
        if (-1 == numFds) {
            ///Look at the error in case it is because of interrupted signal
            if(EINTR == errno) {
                continue;
            }
            else {
                fprintf (stderr, "select returned error with errno[%d]"
                           "[0x%p] %s:%d\n", errno, pthread_self(), __FILE__,
                           __LINE__);
                return(-1);
            }
        }
        if (0 == numFds) {
            ///Time expired.
            fprintf (stderr, "select returned with timeout hit."
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            return(-1);
        }
        if (FD_ISSET(_connectedFd, &readFd)) { ///Success case.
            fprintf (stderr, "select returned true with socket read."
                       "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
            break;
        }
    } while(timercmp(&completionTime, &currentTime, >));

    memset(lengthHeaderBuf, '\0', EP_HEADER_LEN);
    ///Socket is ready to be read. Read the length header for the message
    ///length. Revisit the read timeout of 1sec.
    retval = readMsg(_connectedFd, lengthHeaderBuf, EP_HEADER_LEN, READ_TIMEOUT);
    if (-1 == retval) {
        fprintf (stderr, "readMsg returned error while reading the"
                   " handshake message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    if (EP_HEADER_LEN != retval) {
        fprintf (stderr, "readMsg read partial data than"
                   " handshake message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    ///Chk the format of length header buffer.
    int32_t     payloadLength = 0;
    retval = chkMsgLengthFormat(lengthHeaderBuf, &payloadLength);
    if (-1 == retval) {
        fprintf (stderr, "chkMsgLengthFormat returned error as handshake"
                   " message length received from FPolicy server is improper"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    respPayload = (unsigned char *) malloc(payloadLength * sizeof(unsigned char));
    ///Read the message body.
    retval = readMsg(_connectedFd, respPayload, payloadLength, READ_TIMEOUT);
    if (-1 == retval) {
        fprintf (stderr, "readMsg returned error while reading the"
                   " handshake message payload from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }

    if (payloadLength != retval) {
        fprintf (stderr, "readMsg read partial data than"
                   " handshake message buffer from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }
    *respLength = payloadLength;
    *respBuf    = respPayload;
    return(0);
}

int32_t FSMConnection::sslRecvFSMXmlResp(unsigned char **respBuf,
                                         int *respLength)
{
    int32_t              retval = 0;
    unsigned char        lengthHeaderBuf[EP_HEADER_LEN];
    unsigned char        *respPayload = NULL;

    memset(lengthHeaderBuf, '\0', EP_HEADER_LEN);

    ///Socket is ready to be read. Read the length header for the message
    ///length. Revisit the read timeout of 1sec.
    (void) pthread_mutex_lock(&_connSslMutex);
    retval = sslRecvMsg(_connSsl, lengthHeaderBuf, EP_HEADER_LEN, READ_TIMEOUT);
    (void) pthread_mutex_unlock(&_connSslMutex);

    if (-1 == retval) {
        fprintf (stderr, "readMsg returned error while reading the"
                   " message length response from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    if (EP_HEADER_LEN != retval) {
        fprintf (stderr, "readMsg read partial data than"
                   " XML response message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    ///Chk the format of length header buffer.
    int32_t     payloadLength = 0;
    retval = chkMsgLengthFormat(lengthHeaderBuf, &payloadLength);
    if (-1 == retval) {
        fprintf (stderr, "chkMsgLengthFormat returned error as XML msg resp"
                   " message length received from FPolicy server is improper"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    respPayload = (unsigned char *) malloc(payloadLength * sizeof(unsigned char));
    ///Read the message body.
    (void) pthread_mutex_lock(&_connSslMutex);
    retval = sslRecvMsg(_connSsl, respPayload, payloadLength, READ_TIMEOUT);
    (void) pthread_mutex_unlock(&_connSslMutex);
    if (-1 == retval) {
        fprintf (stderr, "sslRecvMsg returned error while reading the"
                   " handshake message payload from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }

    if (payloadLength != retval) {
        fprintf (stderr, "sslRecvMsg read partial data than"
                   " handshake message buffer from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }
    *respLength = payloadLength;
    *respBuf    = respPayload;
    return(0);
}

int32_t FSMConnection::sslSendFSMXmlReq(FSMXmlReq& reqToSend)
{
    int32_t              retval = 0;
    const unsigned char  *msgPtr = NULL;
    int32_t              msgLength = 0;
    unsigned char        msgLengthHeader[EP_HEADER_LEN];

    memset(msgLengthHeader, '\0', EP_HEADER_LEN);
    ///Send the request in connected socket.TBD: In the below call we are
    ///converting the unsigned length to signed length. Will need to change
    ///type later. I don't know why SSL is taking int for SSL_read
    ///and SSL_write. They should rather have been unsigned. Will place a
    ///check to make sure we don't overflow the int.

    msgLength = reqToSend.getXmlMsgLength();
    fprintf (stderr, "sslSendFSMXmlReq returned got [%s] "
               "message of length %d for FPolicy server [0x%p] %s:%d\n",
               reqToSend.getXmlMsgBuf(), msgLength,
               pthread_self(),__FILE__,__LINE__);

    ///To start with, send the length of the message with proper record
    ///marker.
    formMsgLengthHeader(msgLengthHeader, msgLength);


    ///Concatenate the message length header and actual message(FSMXmlReq)
    std::string   msgLengthStr(reinterpret_cast<const char *> (msgLengthHeader),
                               EP_HEADER_LEN);
    fprintf (stderr, "sslSendFSMXmlReq msgLength string is  [%s] "
               "[0x%p] %s:%d\n", msgLengthStr.c_str(),
               pthread_self(),__FILE__,__LINE__);

    FSMXmlReq     reqToWrite = msgLengthStr + reqToSend;
    msgPtr = reqToWrite.getXmlMsgBuf();
    msgLength = reqToWrite.getXmlMsgLength();

    fprintf (stderr, "sslSendFSMXmlReq will write [%s] "
               "message for FPolicy server [0x%p] %s:%d\n",
               reqToWrite.getXmlMsgBuf(),
               pthread_self(),__FILE__,__LINE__);

    (void) pthread_mutex_lock(&_connSslMutex);
    ///Send the Msg Length and XMLReq together.

    retval = sslSendMsg(_connSsl, msgPtr, msgLength, WRITE_TIMEOUT);

    (void)pthread_mutex_unlock(&_connSslMutex);

    if (retval != msgLength) { ///Error case.
        fprintf (stderr, "sslSendMsg returned error while sending the"
                   "message to FPolicy server [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }
    if (retval == msgLength) { ///Success.
        fprintf (stderr, "XML message written successfully"
                   "[0x%p] %s:%d\n", pthread_self(),__FILE__,__LINE__);
    }

    return(0);
}

int32_t FSMConnection::tcpRecvFSMXmlResp(unsigned char **respBuf,
                                         int32_t *respLength)
{
    int32_t              retval = 0;
    unsigned char        lengthHeaderBuf[EP_HEADER_LEN];
    unsigned char        *respPayload = NULL;

    memset(lengthHeaderBuf, '\0', EP_HEADER_LEN);

    ///Socket is ready to be read. Read the length header for the message
    ///length. Revisit the read timeout of 1sec.
    retval = readMsg(_connectedFd, lengthHeaderBuf, EP_HEADER_LEN, READ_TIMEOUT);

    if (-1 == retval) {
        fprintf (stderr, "readMsg returned error while reading the"
                   " message length response from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }
    if (EP_HEADER_LEN != retval) {
        fprintf (stderr, "readMsg read partial data than"
                   " XML response message length from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    ///Chk the format of length header buffer.
    int32_t     payloadLength = 0;
    retval = chkMsgLengthFormat(lengthHeaderBuf, &payloadLength);
    if (-1 == retval) {
        fprintf (stderr, "chkMsgLengthFormat returned error as XML msg resp"
                   " message length received from FPolicy server is improper"
                   "[0x%p] %s:%d\n", pthread_self(), __FILE__, __LINE__);
        return(-1);
    }

    respPayload = (unsigned char *) malloc(payloadLength * sizeof(unsigned char));
    ///Read the message body.
    retval = readMsg(_connectedFd, respPayload, payloadLength, READ_TIMEOUT);
    if (-1 == retval) {
        fprintf (stderr, "readMsg returned error while reading the"
                   " response  message payload from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }

    if (payloadLength != retval) {
        fprintf (stderr, "readMsg read partial data than"
                   " response message buffer from FPolicy server [0x%p] "
                   "%s:%d\n", pthread_self(), __FILE__, __LINE__);
        free(respPayload);
        respPayload = NULL;
        return(-1);
    }
    *respLength = payloadLength;
    *respBuf    = respPayload;
    return(0);
}


int32_t FSMConnection::tcpSendFSMXmlReq(FSMXmlReq& reqToSend)
{
    int32_t              retval = 0;
    int32_t              writeLen = 0;
    const unsigned char  *msgPtr = NULL;
    int32_t              msgLength = 0;
    unsigned char        msgLengthHeader[EP_HEADER_LEN];

    memset(msgLengthHeader, '\0', EP_HEADER_LEN);
    msgPtr    = reqToSend.getXmlMsgBuf();
    ///Send the request in connected socket.TBD: In the below call we are
    ///converting the unsigned length to signed length. Will need to change
    ///type later. I don't know why SSL is taking int for SSL_read
    ///and SSL_write. They should rather have been unsigned. Will place a
    ///check to make sure we don't overflow the int.
    msgLength = reqToSend.getXmlMsgLength();
    fprintf (stderr, "_tcpSendFSMXmlReq got [%s] "
               "message of length %d for FSM [0x%p] %s:%d\n",
               reqToSend.getXmlMsgBuf(), msgLength,
               pthread_self(),__FILE__,__LINE__);

    ///To start with, send the length of the message with proper record
    ///marker.
    formMsgLengthHeader(msgLengthHeader, msgLength);
    ///Concatenate the message length header and actual message(FSMXmlReq)

    std::string   msgLengthStr(reinterpret_cast<const char *> (msgLengthHeader),
                               EP_HEADER_LEN);

    fprintf (stderr, "_tcpSendFSMXmlReq msgLength string is  [%s] "
               "[0x%p] %s:%d\n", msgLengthStr.c_str(),
               pthread_self(),__FILE__,__LINE__);

    FSMXmlReq     reqToWrite = msgLengthStr + reqToSend;
    msgPtr = reqToWrite.getXmlMsgBuf();
    msgLength = reqToWrite.getXmlMsgLength();
    fprintf (stderr, "_tcpSendFSMXmlReq will write [%s] "
               "message for FSM [0x%p] %s:%d\n",
               reqToWrite.getXmlMsgBuf(),
               pthread_self(),__FILE__,__LINE__);
    printf("\n*********Debug Started****************\n");
    std::cout << msgLengthHeader << endl;
    std::cout << msgLengthStr  << endl;
    for(int i=0; i<msgLength; i++)
    {
        printf("%c",msgPtr[i]);
    }
    printf("\n*******************************\n");
    writeLen = writeMsg(_connectedFd, msgPtr, msgLength, WRITE_TIMEOUT);

    if (writeLen != msgLength) { ///Error case.
        fprintf (stderr, "writeMsg returned error while sending the"
                   "message to FSM [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        return(-1);
    }

    if (writeLen == msgLength) { ///Success.
        fprintf (stderr, "XML message written successfully"
                   "[0x%p] %s:%d\n", pthread_self(),__FILE__,__LINE__);
    }

    return(0);
}

int32_t FSMConnection::doSecNegotiationOverSsl(void)
{
    int         reuse  = 1;
    int         retval = 0;

    _connSsl = SSL_new(_sslContext);

    if (_connSsl == NULL) {
        fprintf (stderr, "SSL_new Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        ERR_print_errors(bio_err);
        BIO_flush(bio_err);
        return(-1);
    }
    _connBIO = BIO_new_socket(_connectedFd, BIO_NOCLOSE);
    if (_connBIO == NULL) {
        fprintf (stderr, "SSL_new Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        ERR_print_errors(bio_err);
        BIO_flush(bio_err);
        SSL_free(_connSsl);
        return(-1);
    }
    SSL_set_bio(_connSsl, _connBIO, _connBIO);

    SSL_set_accept_state(_connSsl);

    ///Get the current time and set the endTime properly.
    struct timeval endTime     = {};
    struct timeval currentTime = {};
    gettimeofday(&endTime, NULL);
    endTime.tv_sec += sslHandshakeTimeout;

    ///Time for SSL handshake. We are non-blocking handshake. Give it a shot
    ///if we see too much of issue, we can change the state to blocking for
    ///SSL handshake. For testing, I have place an infinite loop if handshake
    ///is not done. Once we get it working, will palce the time elapsed based
    ///loop termination as well.
    int32_t   handshakeDone = 0;
    do {
        retval = SSL_do_handshake(_connSsl);
        if (1 == retval) {
            fprintf (stderr, "SSL Handshake Done!!! [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
            handshakeDone = 1;
            ///Break from the loop.
            break;
        }

        switch (SSL_get_error(_connSsl ,retval))
        {
            case SSL_ERROR_NONE:
            {
                fprintf (stderr, "SSL Handshake Done!!! [0x%p] %s:%d\n",
                       pthread_self(),__FILE__,__LINE__);
                handshakeDone = 1;
                break;
            }
            case SSL_ERROR_WANT_READ:
            {
                fprintf (stderr, "SSL_ERROR_WANT_READ. Retry [0x%p] %s:%d\n",
                       pthread_self(),__FILE__,__LINE__);
                ///Retry Again.
                break;
            }
            case SSL_ERROR_WANT_WRITE:
            {
                fprintf (stderr, "SSL_ERROR_WANT_WRITE. Retry "
                           "[0x%p] %s:%d\n", pthread_self(),__FILE__,__LINE__);
                break;
            }
            case SSL_ERROR_SYSCALL:
            {
                ///Will triage based on errno later incase I see issues here.
                ///We need a if else here and return from the do while loop.
                ///TBD.
                fprintf (stderr, "SSL_ERROR_SYSCALL[errno=%d]. Retry "
                           "[0x%p] %s:%d\n", errno, pthread_self(),
                           __FILE__,__LINE__);
                break;
            }
            default:
            {
                fprintf (stderr, "In default case.Err[%d],Errno[%d] case "
                           "missing[0x%p] %s:%d\n", retval, errno, pthread_self(),
                           __FILE__,__LINE__);
                break;
            }
        }
        if (handshakeDone == 1) {
            fprintf (stderr, "SSL Handshake Done!!! [0x%p] %s:%d\n",
                       pthread_self(),__FILE__,__LINE__);
            ///Break from do while loop.
            break;
        }
        gettimeofday(&currentTime, NULL);

    } while(timercmp(&endTime, &currentTime, >));

    if (handshakeDone != 1) {
        fprintf (stderr, "SSL Handshake failed while connecting to FPolicy server. "
                   "Authentication has failed [0x%p] %s:%d\n",
                   pthread_self(),__FILE__,__LINE__);
        ERR_print_errors(bio_err);
        BIO_flush(bio_err);
        SSL_free(_connSsl);
        return(-1);
    }

    fprintf (stderr, "Yeppy!! SSL Handshake is done. "
               "Authentication has gone through!! [0x%p] %s:%d\n",
               pthread_self(),__FILE__,__LINE__);
    return(0);
}

///The below function wait for notification from FSM and process the same
///by placing the request in the notification queue.
int32_t FSMConnection::recvNotification(void)
{
    fd_set readFds;
    int    highFd = INVALID_FD;
    int    retVal = 0;
    int    numFds = 0;

    while(1)
    {
        FD_ZERO(&readFds);
        FD_SET(_connectedFd, &readFds);
        highFd = _connectedFd;

        ///block on listenFds unless we receive a notification.
        numFds = select(highFd+1, &readFds, (fd_set *) 0,
                        (fd_set *) 0, NULL);

        if (-1 == numFds && EINTR == errno) {
            continue;
        }

        if (numFds <= 0) {
            fprintf(stderr, "Select returned error with error[%d],"
                   "[0x%p] %s:%d\n", errno, pthread_self(),
                   __FILE__,__LINE__);
            return(-1);
        }
        ///Fd is ready with data in it.
        fprintf(stderr, "Fd[%d] is ready with data,[0x%p] %s:%d\n",
               _connectedFd, pthread_self(), __FILE__,__LINE__);
        ///Receive notification.
        retVal = readAndEnqueue();
        if (-1 == retVal) {
            fprintf(stderr, "Select returned error with error[%d],"
                   "[0x%p] %s:%d\n", errno, pthread_self(),
                   __FILE__,__LINE__);
            return(-1);
        }
    }
}

///The job of the connection receive thread is bascally read data from
///FSM and queue it so that woker threads will work on it.
void * newConnectCreate(void *connectFdPtr)
{
    int retval = 0;
    int connectedFd = INVALID_FD;

    ///Set the connected socket non blocking.
    int* connectedFdPtr = (int *) connectFdPtr;
    connectedFd  = *connectedFdPtr;

    retval = fcntl(connectedFd, F_SETFL, O_NONBLOCK);
    if (retval == -1) {
        fprintf (stderr, "fcntl Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        close(connectedFd);
        connectedFd = INVALID_FD;
        pthread_exit(NULL);
    }

    ///We received a new connection. Create a new connection object.
    FSMConnection *connectionObj = new FSMConnection(vsId,
                                                     polName,
                                                     connectedFd,
                                                     sslAuthEnabled,
                                                     FSMipString,
                                                     sessionId.c_str(),
                                                     pthread_self());

    if (true == sslAuthEnabled) {
        std::stringstream   certPath;
        std::string         caCertPath;
        std::string         serverCertPath;
        std::string         serverKeyPath;

        certPath << dirname << "/" << CLIENT_CA_CERT ;
        caCertPath = certPath.str();
        fprintf (stderr, "caCertPath is [%s].[0x%p] %s:%d\n",
                 caCertPath.c_str(),pthread_self(), __FILE__,__LINE__);

        certPath.str("");
        certPath << dirname << "/" << SERVER_CERT ;
        serverCertPath = certPath.str();
        fprintf (stderr, "serverCertPath is [%s].[0x%p] %s:%d\n",
                 serverCertPath.c_str(),pthread_self(), __FILE__,__LINE__);

        certPath.str("");
        certPath << dirname << "/" << SERVER_KEY ;
        serverKeyPath = certPath.str();
        fprintf (stderr, "serverKeyPath is [%s].[0x%p] %s:%d\n",
                 serverKeyPath.c_str(),pthread_self(), __FILE__,__LINE__);

        retval = connectionObj->fpServerSslInit(caCertPath.c_str(),
                                                serverCertPath.c_str(),
                                                serverKeyPath.c_str(),
                                                PASSWORD);

        if (-1 == retval) {
            fprintf (stderr, "fpServerSslInit failed.[0x%p] %s:%d\n",
                    pthread_self(), __FILE__,__LINE__);
            retval = connectionObj->disconnectFSM();
            delete(connectionObj);
            pthread_exit(NULL);
        }
        ///Do the necessary security negotiations.
        retval = connectionObj->doSecNegotiationOverSsl();
        if (-1 == retval) {
            fprintf (stderr, "fpServerSslInit failed.[0x%p] %s:%d\n",
                    pthread_self(), __FILE__,__LINE__);
            retval = connectionObj->disconnectFSM();
            delete(connectionObj);
            pthread_exit(NULL);
        }
    }
    ///Start with FPolicy handshake. Receive the version supported by FSM
    ///and suggest one of them.
    retval = connectionObj->doFpolicyHandshake();
    if (-1 == retval) {
        fprintf (stderr, "doFpolicyHandshake failed.[0x%p] %s:%d\n",
                pthread_self(), __FILE__,__LINE__);
        retval = connectionObj->disconnectFSM();
        delete(connectionObj);
        pthread_exit(NULL);
    }
    ///All handshakes are done and connection is established. Time to receive
    ///notification from FSM.
    retval = connectionObj->recvNotification();
    if (-1 == retval) {
        fprintf (stderr, "doFpolicyHandshake failed.[0x%p] %s:%d\n",
                pthread_self(), __FILE__,__LINE__);
        retval = connectionObj->disconnectFSM();
        delete(connectionObj);
        pthread_exit(NULL);
    }
}

int32_t acceptFSMConnection(void)
{
    int         reuse  = 1;
    int         retval = 0;
    int         listenFdIpv4 = INVALID_FD;
    int         listenFdIpv6 = INVALID_FD;
    int         connectedFd  = INVALID_FD;

    struct sockaddr_in      fpServerAddr = {};
    struct sockaddr_in      fsmAddr = {};
    struct sockaddr_in6     fpServerAddr6 = {};
    struct sockaddr_in6     fsmAddr6 = {};
    struct sockaddr_storage peerName;
    socklen_t length = sizeof(peerName);
    char      ipString[INET6_ADDRSTRLEN + 1];
    uint32_t  port   = 0;
    pthread_t tid;

    listenFdIpv4 = socket(AF_INET, SOCK_STREAM, 0);

    if (listenFdIpv4 < 0) {
        fprintf (stderr, "Error[%d] in creating a socket with"
                "error string[%s]\n",errno, strerror(errno));
        return(-1);
    }

    listenFdIpv6 = socket(AF_INET6, SOCK_STREAM, 0);

    if (listenFdIpv6 < 0) {
        fprintf (stderr, "Error[%d] in creating a socket with"
                "error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        listenFdIpv4 = INVALID_FD;
        return(-1);
    }

    retval = fcntl(listenFdIpv4, F_SETFL, O_NONBLOCK);
    if (retval != 0) {
        fprintf (stderr, "Error[%d] in making the socket non-blocking"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }
    retval = fcntl(listenFdIpv6, F_SETFL, O_NONBLOCK);
    if (retval != 0) {
        fprintf (stderr, "Error[%d] in making the socket non-blocking"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    if (setsockopt(listenFdIpv4, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse,
                   sizeof(reuse)) < 0) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }
    if (setsockopt(listenFdIpv6, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse,
                   sizeof(reuse)) < 0) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    int32_t    sendBufSize    = SOCKET_SEND_BUF_SIZ;
    socklen_t  sendBufSizeLen = sizeof(sendBufSize);
    retval = setsockopt(listenFdIpv4 , SOL_SOCKET, SO_SNDBUF,
                        (void *) &sendBufSize, sendBufSizeLen);
    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    int32_t    recvBufSize    = SOCKET_RECV_BUF_SIZ;
    socklen_t  recvBufSizeLen = sizeof(recvBufSize);
    retval = setsockopt(listenFdIpv4, SOL_SOCKET, SO_RCVBUF,
                        (void *) &recvBufSize, recvBufSizeLen);
    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    retval = setsockopt(listenFdIpv6, SOL_SOCKET, SO_SNDBUF,
                        (void *) &sendBufSize, sendBufSizeLen);
    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }


    retval = setsockopt(listenFdIpv6, SOL_SOCKET, SO_RCVBUF,
                        (void *) &recvBufSize, recvBufSizeLen);
    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    ///TCP_NODELAY
    int32_t on = 1;
    socklen_t onLen = sizeof(on);
    retval = setsockopt(listenFdIpv4, IPPROTO_TCP, TCP_NODELAY,
                        (void *) &on, onLen);

    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    on = 1;
    retval = setsockopt(listenFdIpv6, IPPROTO_TCP, TCP_NODELAY,
                        (void *) &on, onLen);

    if (-1 == retval) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    /* make IPv6 listening socket IPv6 only */
    int yes = 1;
    if (setsockopt(listenFdIpv6, IPPROTO_IPV6, IPV6_V6ONLY, &yes, sizeof(yes)) < 0) {
        fprintf (stderr, "Error[%d] in setting the socket option"
                "with error string[%s]\n",errno, strerror(errno));
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    ///Do the local bind for Ipv4 Socket.
    memset(&fpServerAddr, '\0', sizeof(fpServerAddr));
    fpServerAddr.sin_family = AF_INET;
    fpServerAddr.sin_port   = htons(FpServerPort);
    fpServerAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(listenFdIpv4, (struct sockaddr *) &fpServerAddr,
             sizeof(fpServerAddr)) < 0) {
        fprintf (stderr, "bind Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    fpServerAddr6.sin6_family = AF_INET6;
    fpServerAddr6.sin6_port   = htons(FpServerPort);
    fpServerAddr6.sin6_addr   = in6addr_any;
    if (bind(listenFdIpv6, (struct sockaddr *) &fpServerAddr6,
             sizeof(fpServerAddr6)) < 0) {
        fprintf (stderr, "bind failed. [0x%p] %s:%d\n",
                pthread_self(),__FILE__,__LINE__);
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    if (listen(listenFdIpv4, 20) < 0) {
        fprintf (stderr, "listen Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    if (listen(listenFdIpv6, 20) < 0) {
        fprintf (stderr, "listen Failed with error[%d]. Error in string[%s] "
                "[0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                __FILE__,__LINE__);
        close(listenFdIpv4);
        close(listenFdIpv6);
        listenFdIpv4 = INVALID_FD;
        listenFdIpv6 = INVALID_FD;
        return(-1);
    }

    ///Do a select to know if any one of the two listening socket
    ///accepted connection from FSM.
    fd_set    listenFds;
    int       highFd = INVALID_FD;
    int       numFds = 0;

    while(1)
    {
        FD_ZERO(&listenFds);
        FD_SET(listenFdIpv4, &listenFds);
        FD_SET(listenFdIpv6, &listenFds);
        highFd = listenFdIpv6;

        if (highFd < listenFdIpv4) {
            highFd = listenFdIpv4;
        }

        ///block on listenFds unless we receive a notification.
        numFds = select(highFd+1, &listenFds, (fd_set *) 0,
                        (fd_set *) 0, NULL);

        if (-1 == numFds && EINTR == errno) {
            continue;
        }

        if (numFds <= 0) {
            fprintf(stderr, "Select returned error with error[%d],"
                   "[0x%p] %s:%d\n", errno, pthread_self(),
                   __FILE__,__LINE__);
            close(listenFdIpv4);
            close(listenFdIpv6);
            listenFdIpv4 = INVALID_FD;
            listenFdIpv6 = INVALID_FD;
            return(-1);
        }
        if (FD_ISSET(listenFdIpv4, &listenFds)) {
            ///Now accept the connection.
            struct sockaddr_in fpsSa = {};
            socklen_t    length = sizeof(fpsSa);
            connectedFd = accept(listenFdIpv4, (struct sockaddr *) &fpsSa, &length);
            if (connectedFd < 0) {
                fprintf (stderr, "accept Failed with error[%d]. Error in string[%s]"
                        " [0x%p] %s:%d\n", errno, strerror(errno), pthread_self(),
                        __FILE__,__LINE__);
                close(listenFdIpv4);
                close(listenFdIpv6);
                listenFdIpv4 = INVALID_FD;
                listenFdIpv6 = INVALID_FD;
                return(-1);
            }

            retval = chkSocketConnectStatus(connectedFd);
            if (retval != 0) {
                ///Socket is not connected yet or got disconnected!!!
                fprintf (stderr, "chkSocketConnectStatus failed. "
                        "Socket is not connected [0x%p] %s:%d\n",
                        pthread_self(),__FILE__,__LINE__);
                close(listenFdIpv4);
                close(listenFdIpv6);
                listenFdIpv4 = INVALID_FD;
                listenFdIpv6 = INVALID_FD;
                return(-1);
            }

            ///Now that we accepted the connection, create a thread for handling
            ///connected socket.
            (void) pthread_create(&tid, NULL, newConnectCreate, &connectedFd);
            ///Detach the thread.
            (void) pthread_detach(tid);
        }
        if (FD_ISSET(listenFdIpv6, &listenFds)) {
            ///Now accept the connection.
            struct sockaddr_in6 fpsSa6 = {};
            socklen_t    length = sizeof(fpsSa6);
            connectedFd = accept(listenFdIpv6, (struct sockaddr *) &fpsSa6,
                                 &length);
            if (connectedFd < 0) {
                fprintf (stderr, "accept Failed with error[%d]. Error in "
                        "string[%s] [0x%p] %s:%d\n", errno, strerror(errno),
                        pthread_self(), __FILE__,__LINE__);
                close(listenFdIpv4);
                close(listenFdIpv6);
                listenFdIpv4 = INVALID_FD;
                listenFdIpv6 = INVALID_FD;
                return(-1);
            }
            ///Received a connection on IPv4 socket. Let the below
            ///call give a message on the connecting node address.
            retval = chkSocketConnectStatus(connectedFd);
            if (retval != 0) {
                ///Socket is not connected yet or got disconnected!!!
                fprintf (stderr, "chkSocketConnectStatus failed. "
                        "Socket is not connected [0x%p] %s:%d\n",
                        pthread_self(),__FILE__,__LINE__);
                close(listenFdIpv4);
                close(listenFdIpv6);
                listenFdIpv4 = INVALID_FD;
                listenFdIpv6 = INVALID_FD;
                return(-1);
            }
            ///Now that we accepted the connection, create a thread for handling
            ///connected socket.
            (void) pthread_create(&tid, NULL, newConnectCreate, &connectedFd);
            ///Now detach the thread.
            (void) pthread_detach(tid);
        }
    }
    ///Check which fd is ready for receiving a new connection.
    return(0);
}

FSMConnection::FSMConnection(uint32_t   vsId,
                             char       *polName,
                             int        connectedFd,
                             bool       sslAuthEnabled,
                             char       *FSMIpAddr,
                             const char *sessionId,
                             pthread_t  threadId)
{
    _vserverId = vsId;
    strncpy(_policyName, polName, MAX_POLICY_LEN);
    _policyName[MAX_POLICY_LEN] = '\0';
    _connectedFd = connectedFd;
    _sslAuthEnabled = sslAuthEnabled;
    strncpy(_FSMIpAddress, FSMIpAddr, MAX_IP_ADDRESS_LEN);
    _FSMIpAddress[MAX_IP_ADDRESS_LEN] = '\0';
    strncpy(_sessionId, sessionId, FPS_MAX_UUID_LEN);
    _sessionId[FPS_MAX_UUID_LEN] = '\0';
    _threadId = threadId;
    (void)pthread_mutex_init(&_connSslMutex, NULL);
    _sslContext = NULL;
    _connSsl = NULL;
    _connBIO = NULL;
    _certBuffer = NULL;
}

FSMConnection::~FSMConnection()
{
    (void) pthread_mutex_destroy(&_connSslMutex);

    SSL_CTX_free(_sslContext);
    _sslContext = NULL;

    SSL_free(_connSsl);
    _connSsl = NULL;

    BIO_flush(bio_err);
}

int32_t FSMConnection::readAndEnqueue(void)
{
    int32_t        retval = 0;
    unsigned char  *msgBuf = NULL;
    int32_t        length = 0;
    uint64_t       reqId = 0;
    unsigned char  *reqType = NULL;
    FPS_Notification *notificationPtr;

    ///Read the response from the connected socket.
    ///Wait for handshake request from FSM..
    retval = recvMsg(&msgBuf, &length);
    if (-1 == retval) {
        fprintf (stderr, "Error in recvMsg while sending a response."
                "return with error [0x%p] %s:%d\n", pthread_self(),
                __FILE__, __LINE__);
        return(-1);
    }

    ///Enqueue the message to the global notification queue which will
    ///be picked by the worker threads working on notifications.
    notificationPtr = new FPS_Notification(msgBuf, length, this);
    notificationPtr->enqueueNotficationObj();

    return(retval);
}
