
#include"fpolicyserver.h"

int main()
{

//freopen("c.in", "rt", stdin);
    freopen("c.txt", "wt", stdout);
    fpolicy server ;
    server.start();

    return 0;
}
